prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Absentismo'
,p_alias=>'ABSENTISMO'
,p_step_title=>'Absentismo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'require(["ojs/ojtagcloud"] ,function() {});'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240507085840'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15043047298680437)
,p_plug_name=>'Absentismo (%)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>2
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16443883754725602)
,p_region_id=>wwv_flow_imp.id(15043047298680437)
,p_chart_type=>'dial'
,p_title=>'Pct absentismo'
,p_width=>'90'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'percent'
,p_value_format_scaling=>'auto'
,p_tooltip_rendered=>'Y'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16443997929725603)
,p_chart_id=>wwv_flow_imp.id(16443883754725602)
,p_seq=>10
,p_name=>'Pct absentismo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'label, tot_dias, val_dias,',
'case',
' when value <= 5 then :V_COLOR_GREEN',
' when value > 5 and value <= 7 then :V_COLOR_YELLOW',
' when value > 7 then :V_COLOR_RED',
' end a_color, pct',
' from (',
'select ''Absentismo total'' label,',
'round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100value, (215/12)*tot_emp*n_meses tot_dias, dias_abs val_dias,',
'round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 nval,',
' null pct from (',
'select count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO ABST ',
'     join EMPLEADOS EMPS on (EMPS.codigo_empleado = ABST.codigo_empleado)',
'     where to_char(ABST.MES, ''YYYY'') = ''2021'' and EMPS.dato_valido = ''S''     ',
'     group by ABST.mes order by ABST.mes',
')',
't1) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by dias_abs, n_meses))'))
,p_items_value_column_name=>'VAL_DIAS'
,p_items_max_value=>'TOT_DIAS'
,p_color=>'&A_COLOR.'
,p_items_label_rendered=>false
,p_gauge_plot_area_color=>'&A_COLOR.'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15044007789680447)
,p_plug_name=>unistr('Total d\00EDas')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16259323336274248)
,p_region_id=>wwv_flow_imp.id(15044007789680447)
,p_chart_type=>'dial'
,p_width=>'90'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'number'
,p_value_format_scaling=>'auto'
,p_tooltip_rendered=>'Y'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16259423651274249)
,p_chart_id=>wwv_flow_imp.id(16259323336274248)
,p_seq=>10
,p_name=>'Ausencia total'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, dias_m, case',
' when dias_m <= 500 then :V_COLOR_GREEN --''#76b417''',
' when dias_m > 500 and dias_m <= 1000 then :V_COLOR_YELLOW --''#fbb03b''',
' when dias_m > 1000 then :V_COLOR_RED --''#e10000''',
' end a_color from (',
unistr('select ''D\00EDas totales'' label, round(sum(nvl(n_dias, 0)),0) dias_m from ABSENTISMO ABST'),
' join EMPLEADOS EMPS on (EMPS.codigo_empleado = ABST.codigo_empleado)',
' where to_char(ABST.MES, ''YYYY'') = ''2021'' and EMPS.dato_valido = ''S'')'))
,p_items_value_column_name=>'DIAS_M'
,p_items_max_value=>'DIAS_M'
,p_color=>'&A_COLOR.'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15044188207680448)
,p_plug_name=>'Absentismo por mes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15044209143680449)
,p_region_id=>wwv_flow_imp.id(15044188207680448)
,p_chart_type=>'line'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15044324308680450)
,p_chart_id=>wwv_flow_imp.id(15044209143680449)
,p_seq=>10
,p_name=>'Absentismo mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(mes, ''Mon'') label, to_char(mes, ''Mon'') mes_c, round(sum(nvl(n_dias, 0)), 2) dias_m ',
'from ABSENTISMO ',
'where to_char(MES, ''YYYY'') = :V_YEAR_DEFAULT',
'group by mes order by mes'))
,p_items_value_column_name=>'DIAS_M'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'DIAS_M'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15648494951848601)
,p_chart_id=>wwv_flow_imp.id(15044209143680449)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15648531042848602)
,p_chart_id=>wwv_flow_imp.id(15044209143680449)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>unistr('N\00BA D\00EDas')
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15649640547848613)
,p_plug_name=>'Dummy2'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15649536314848612)
,p_plug_name=>unistr('N\00BA d\00EDas por tipo de absentismo')
,p_parent_plug_id=>wwv_flow_imp.id(15649640547848613)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h480:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'',
'lv_cloud_tag_items clob;',
'lv_chart_output clob;',
'',
'',
'Begin ',
'',
'-- Prepare JSON for Tag Cloud Items',
'',
'select JSON_ARRAYAGG',
'(',
'JSON_OBJECT',
'	(',
'	KEY ''label'' VALUE TIPO_ABSENTISMO,',
'	KEY ''value'' VALUE N_DIAS,',
'	KEY ''color'' VALUE C_ABS,',
unistr('	KEY ''shortDesc'' VALUE ''MOTIVO: '' || TIPO_ABSENTISMO || '' - NUM D\00CDAS: '' || N_DIAS'),
'    )',
'    FORMAT JSON ORDER BY TIPO_ABSENTISMO RETURNING CLOB',
') into lv_cloud_tag_items',
'from (select c_abs as C_ABS, t_abs as TIPO_ABSENTISMO, sum(n_dias) N_DIAS from (',
'select',
'      case',
'           when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%'' then ''#046a13''',
unistr('           when tipo_absentismo like ''%Viernes de libre disposici\00F3n%'' then ''#f9e904'''),
'           when tipo_absentismo like ''%Fallecimiento conyuge, hijos padres o hermanos%'' then ''#fdc7c7''',
unistr('           when tipo_absentismo like ''%Ausencia M\00E9dica%'' then ''#193591'''),
'           when tipo_absentismo like ''%Operacion resto familiares%'' then ''#2E86C1''',
'           when tipo_absentismo like ''%Mudanza%'' then ''#7D3C98''',
'           when tipo_absentismo like ''%Baja IT larga duracion%'' then ''#a40a40''',
'           when tipo_absentismo like ''%Baja IT COVID%'' then ''#F39C12''',
'           when tipo_absentismo like ''%Matrimonio%'' then ''#fb9745''',
unistr('           when tipo_absentismo like ''%Operaci\00F3n conyuge, hijos, padres y hermanos%'' then ''#333c4e'''),
unistr('           when tipo_absentismo like ''%Baja IT corta duraci\00F3n%'' then ''#0897df'''),
'           when tipo_absentismo like ''%Lactancia acumulada%'' then ''#E74C3C''',
'      end c_abs,',
'      case when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%''',
'           then ''Maternidad/Paternidad''',
'           else tipo_absentismo',
'      end t_abs,',
'      n_dias',
'from absentismo where to_char(mes, ''yyyy'') = ''2021'') group by c_abs, t_abs);',
'',
'',
'-- Generate Chart for Tag Cloud and Pass the JSON',
'',
'lv_chart_output := ''<oj-tag-cloud',
'            id = "TAG_CLOUD1"',
'            layout ="cloud"',
'            selection-mode = "single"',
'            animation-on-display="auto"',
'            animation-on-data-change="auto"',
'            items="'' || apex_escape.html(lv_cloud_tag_items) || ''">',
'            </oj-tag-cloud>'';',
'',
'',
'return lv_chart_output;',
'',
'End;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16258135433274236)
,p_plug_name=>'Dummy3'
,p_parent_plug_id=>wwv_flow_imp.id(15649640547848613)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15648695114848603)
,p_plug_name=>'Absentismo por comunidad'
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--showIcon:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(15648777679848604)
,p_region_id=>wwv_flow_imp.id(15648695114848603)
,p_height=>160
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
,p_copyright_notice=>' '
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(15648896497848605)
,p_map_region_id=>wwv_flow_imp.id(15648777679848604)
,p_name=>'Absentismo'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
't2.comunidad, round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 n_dias,',
'to_char(round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100)||''%'' pc_dias',
', geometry',
'from (',
'select codigo_centro, count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_centro, codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select codigo_centro, sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select codigo_centro, mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021'' group by codigo_centro, mes order by mes',
')',
't1',
' group by codigo_centro) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by codigo_centro, dias_abs, n_meses) t3',
'join centros t2 on t2.codigo_centro = t3.codigo_centro',
'join map_comunidades t4 on t4.name = t2.comunidad'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'TealGrn'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'N_DIAS'
,p_fill_opacity=>.5
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&COMUNIDAD.: &PC_DIAS.</b>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_COMUNIDAD:\&COMUNIDAD.\'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15649064046848607)
,p_plug_name=>unistr('Por categor\00EDa laboral')
,p_region_name=>'fancy'
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--showIcon:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15649104048848608)
,p_region_id=>wwv_flow_imp.id(15649064046848607)
,p_chart_type=>'pie'
,p_height=>'160'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'    options.dataFilter = function( data ) {',
'        data.series[0].pieSliceExplode = 1;',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15649208850848609)
,p_chart_id=>wwv_flow_imp.id(15649104048848608)
,p_seq=>10
,p_name=>unistr('Absentismo por categor\00EDa')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empl.categ_profesional, round(sum(n_dias)*100/ntot, 0) value,',
'      case',
'           when categ_profesional like ''%COMERCIAL%'' then ''#a40a40''',
'           when categ_profesional like ''%DESARROLLO%'' then ''#046a13''',
'           when categ_profesional like ''%SOPORTE%'' then ''#fb9745''',
'           when categ_profesional like ''%TECNICO%'' then ''#fdc7c7''',
'      end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' group by empl.categ_profesional, ntot order by sum(n_dias) desc'))
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'CATEG_PROFESIONAL'
,p_items_label_rendered=>true
,p_items_label_position=>'start'
,p_items_label_display_as=>'PERCENT'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_CATEG_PROFESIONAL:\&CATEG_PROFESIONAL.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15652331330848640)
,p_plug_name=>'Por tipo de absentismo'
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15652453471848641)
,p_region_id=>wwv_flow_imp.id(15652331330848640)
,p_chart_type=>'donut'
,p_height=>'160'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15652537522848642)
,p_chart_id=>wwv_flow_imp.id(15652453471848641)
,p_seq=>10
,p_name=>'Absentismo por motivo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tipo_absentismo, round(sum(n_dias)*100/ntot, 0) value, ntot,',
'      case',
'           when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%'' then ''#046a13''',
unistr('           when tipo_absentismo like ''%Viernes de libre disposici\00F3n%'' then ''#f9e904'''),
'           when tipo_absentismo like ''%Fallecimiento conyuge, hijos padres o hermanos%'' then ''#fdc7c7''',
unistr('           when tipo_absentismo like ''%Ausencia M\00E9dica%'' then ''#193591'''),
'           when tipo_absentismo like ''%Operacion resto familiares%'' then ''#2E86C1''',
'           when tipo_absentismo like ''%Mudanza%'' then ''#7D3C98''',
'           when tipo_absentismo like ''%Baja IT larga duracion%'' then ''#a40a40''',
'           when tipo_absentismo like ''%Baja IT COVID%'' then ''#F39C12''',
'           when tipo_absentismo like ''%Matrimonio%'' then ''#fb9745''',
unistr('           when tipo_absentismo like ''%Operaci\00F3n conyuge, hijos, padres y hermanos%'' then ''#333c4e'''),
unistr('           when tipo_absentismo like ''%Baja IT corta duraci\00F3n%'' then ''#0897df'''),
'           when tipo_absentismo like ''%Lactancia acumulada%'' then ''#E74C3C''',
'      end series_colors',
' from absentismo abs_1',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' group by abs_1.tipo_absentismo, ntot order by sum(n_dias) desc'))
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'TIPO_ABSENTISMO'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_TIPO_ABSENTISMO:\&TIPO_ABSENTISMO.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16255190859274206)
,p_plug_name=>unistr('Por g\00E9nero y edad')
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16255264156274207)
,p_region_id=>wwv_flow_imp.id(16255190859274206)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16255381625274208)
,p_chart_id=>wwv_flow_imp.id(16255264156274207)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y edad')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empl.rangos_edad, empl.genero_mf, round(sum(n_dias)*100/ntot, 0) value, to_char(round(sum(n_dias)*100/ntot, 0))||''%'' v_lab,',
'case',
'    when empl.rangos_edad like ''%26-35%'' then 0',
'    when empl.rangos_edad like ''36-45'' then 1',
'    when empl.rangos_edad like ''46-55'' then 2',
'    when empl.rangos_edad like ''> 55'' then 3',
'end n_rango,',
'case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.dato_valido = ''S'' group by empl.rangos_edad, empl.genero_mf, ntot order by n_rango',
''))
,p_series_name_column_name=>'GENERO_MF'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'RANGOS_EDAD'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_GENERO_MF,P15_RANGOS_EDAD:\&GENERO_MF.\,\&RANGOS_EDAD.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16255416103274209)
,p_chart_id=>wwv_flow_imp.id(16255264156274207)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'percent'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16255540219274210)
,p_chart_id=>wwv_flow_imp.id(16255264156274207)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16255621637274211)
,p_plug_name=>unistr('Por g\00E9nero y categor\00EDa laboral')
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16255744005274212)
,p_region_id=>wwv_flow_imp.id(16255621637274211)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16255841777274213)
,p_chart_id=>wwv_flow_imp.id(16255744005274212)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y categor\00EDa profesional')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, genero, round(num_g*100/sum(num_g) over(partition by label)) value, series_colors from (',
' select  empl.categ_profesional label, empl.genero_mf genero, count(*) num_g,',
' case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.genero_mf in (''M'', ''F'') group by empl.categ_profesional, empl.genero_mf',
' order by label',
' )',
''))
,p_series_name_column_name=>'GENERO'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_CATEG_PROFESIONAL,P15_GENERO_MF:\&LABEL.\,\&GENERO.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16255984508274214)
,p_chart_id=>wwv_flow_imp.id(16255744005274212)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16256008378274215)
,p_chart_id=>wwv_flow_imp.id(16255744005274212)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>100
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16256108962274216)
,p_plug_name=>unistr('Por g\00E9nero y tipo de absentismo')
,p_parent_plug_id=>wwv_flow_imp.id(16258135433274236)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16256226267274217)
,p_region_id=>wwv_flow_imp.id(16256108962274216)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16256321112274218)
,p_chart_id=>wwv_flow_imp.id(16256226267274217)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y tipo absentismo')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, genero, round(num_g*100/sum(num_g) over(partition by label)) value, series_colors from (',
' select  abs_1.tipo_absentismo label, empl.genero_mf genero, count(*) num_g,',
' case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.genero_mf in (''M'', ''F'') group by abs_1.tipo_absentismo, empl.genero_mf',
' order by label',
' )',
''))
,p_series_name_column_name=>'GENERO'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_GENERO_MF,P15_TIPO_ABSENTISMO:\&GENERO.\,\&LABEL.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16256406325274219)
,p_chart_id=>wwv_flow_imp.id(16256226267274217)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16256538049274220)
,p_chart_id=>wwv_flow_imp.id(16256226267274217)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>100
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16258708123274242)
,p_name=>'abs_color_pct'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15043047298680437)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16258847200274243)
,p_event_id=>wwv_flow_imp.id(16258708123274242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-BadgeList-value").each(function()',
'{',
'    if (parseInt($(this).text()) < 10) $(this).css(',
'    {',
'        "background-color": "#76b417"',
'    });',
'    else if (parseInt($(this).text()) > 30) $(this).css(',
'    {',
'        "background-color": "#e10000"',
'    });',
'    else $(this).css(',
'    {',
'        "background-color": "#fbb03b"',
'    });',
'});'))
);
wwv_flow_imp.component_end;
end;
/
