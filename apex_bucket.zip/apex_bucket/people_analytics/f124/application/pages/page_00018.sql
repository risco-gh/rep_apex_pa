prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Informe Empleados TEST 2'
,p_alias=>'INFORME-EMPLEADOS-TEST'
,p_step_title=>'Informe Empleados TEST 2'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(13465178960287177)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240411092707'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(17238057328774213)
,p_name=>'Search Results A'
,p_region_name=>'abs_r'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>5
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'--       ABS.MES MES,',
'       ABS.CODIGO_EMPLEADO CODIGO_EMPLEADO,',
'       ABS.CODIGO_CENTRO CODIGO_CENTRO,',
'       ABS.TIPO_ABSENTISMO TIPO_ABSENTISMO,',
'       SUM(ABS.N_DIAS) N_DIAS',
'  from EMPLEADOS EMP',
'  join CENTROS CTS on (CTS.CODIGO_CENTRO = EMP.CODIGO_CENTRO)',
'  join ABSENTISMO ABS on (ABS.CODIGO_EMPLEADO = EMP.CODIGO_EMPLEADO)  where',
'     (:P18_TIPO_CONTRATO IS NULL OR REGEXP_LIKE(:P18_TIPO_CONTRATO, EMP.TIPO_CONTRATO)) AND',
'     (:P18_RANGOS_EDAD IS NULL OR REGEXP_LIKE(:P18_RANGOS_EDAD, EMP.RANGOS_EDAD)) AND',
'     (:P18_CATEG_PROFESIONAL IS NULL OR REGEXP_LIKE(:P18_CATEG_PROFESIONAL, EMP.CATEG_PROFESIONAL)) AND',
'     (:P18_PUESTO_TRABAJO IS NULL OR REGEXP_LIKE(:P18_PUESTO_TRABAJO, EMP.PUESTO_TRABAJO)) AND',
'     (:P18_GENERO_MF IS NULL OR REGEXP_LIKE(:P18_GENERO_MF, EMP.GENERO_MF)) AND',
'     (:P18_PROVINCIA IS NULL OR REGEXP_LIKE(:P18_PROVINCIA, CTS.PROVINCIA)) AND',
'     (:P18_CLAVE_SN IS NULL OR REGEXP_LIKE(:P18_CLAVE_SN, EMP.CLAVE_SN))',
'group by ABS.CODIGO_EMPLEADO, ABS.CODIGO_CENTRO, ABS.TIPO_ABSENTISMO',
'order by ABS.CODIGO_EMPLEADO, ABS.TIPO_ABSENTISMO'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593007056558910)
,p_query_column_id=>1
,p_column_alias=>'CODIGO_EMPLEADO'
,p_column_display_sequence=>10
,p_column_heading=>'Codigo Empleado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593171047558911)
,p_query_column_id=>2
,p_column_alias=>'CODIGO_CENTRO'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593246876558912)
,p_query_column_id=>3
,p_column_alias=>'TIPO_ABSENTISMO'
,p_column_display_sequence=>50
,p_column_heading=>'Tipo Absentismo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593325558558913)
,p_query_column_id=>4
,p_column_alias=>'N_DIAS'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(17593812907558918)
,p_name=>'Search Results B'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       EMP.CODIGO_EMPLEADO CODIGO_EMPLEADO,',
'       ABS.MES MES,',
'       SUM(ABS.N_DIAS) N_DIAS,',
'       SLS.SALARIO',
'  from EMPLEADOS EMP',
'  join CENTROS CTS on (CTS.CODIGO_CENTRO = EMP.CODIGO_CENTRO)',
'  join ABSENTISMO ABS on (ABS.CODIGO_EMPLEADO = EMP.CODIGO_EMPLEADO)',
'  join SALARIOS SLS on (SLS.CODIGO_EMPLEADO = EMP.CODIGO_EMPLEADO AND SLS.MM_YYYY = ABS.MES)',
'  where',
'     (:P18_TIPO_CONTRATO IS NULL OR REGEXP_LIKE(:P18_TIPO_CONTRATO, EMP.TIPO_CONTRATO)) AND',
'     (:P18_RANGOS_EDAD IS NULL OR REGEXP_LIKE(:P18_RANGOS_EDAD, EMP.RANGOS_EDAD)) AND',
'     (:P18_CATEG_PROFESIONAL IS NULL OR REGEXP_LIKE(:P18_CATEG_PROFESIONAL, EMP.CATEG_PROFESIONAL)) AND',
'     (:P18_PUESTO_TRABAJO IS NULL OR REGEXP_LIKE(:P18_PUESTO_TRABAJO, EMP.PUESTO_TRABAJO)) AND',
'     (:P18_GENERO_MF IS NULL OR REGEXP_LIKE(:P18_GENERO_MF, EMP.GENERO_MF)) AND',
'     (:P18_PROVINCIA IS NULL OR REGEXP_LIKE(:P18_PROVINCIA, CTS.PROVINCIA)) AND',
'     (:P18_CLAVE_SN IS NULL OR REGEXP_LIKE(:P18_CLAVE_SN, EMP.CLAVE_SN))',
'  group by EMP.CODIGO_EMPLEADO, ABS.MES, SLS.SALARIO',
'  order by EMP.CODIGO_EMPLEADO, ABS.MES',
'  '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593981190558919)
,p_query_column_id=>1
,p_column_alias=>'CODIGO_EMPLEADO'
,p_column_display_sequence=>10
,p_column_heading=>'Codigo Empleado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17594032404558920)
,p_query_column_id=>2
,p_column_alias=>'MES'
,p_column_display_sequence=>20
,p_column_heading=>'Mes'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17594154631558921)
,p_query_column_id=>3
,p_column_alias=>'N_DIAS'
,p_column_display_sequence=>30
,p_column_heading=>unistr(' D\00EDas ausente')
,p_use_as_row_header=>'N'
,p_column_format=>'990D99'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17594472885558924)
,p_query_column_id=>4
,p_column_alias=>'SALARIO'
,p_column_display_sequence=>40
,p_column_heading=>'Salario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31334613997901158)
,p_plug_name=>'Dashboard'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="color: #008000; font-weight: bold">',
'    <div id="Dashboard"></div>',
'</span>',
'<span style="color: #BB4444"></span>',
'<span style="color: #008000; font-weight: bold"></span>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(31398591527607843)
,p_name=>'Search Results'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'CODIGO_EMPLEADO, CATEG_PROFESIONAL, PUESTO_TRABAJO, EDAD, CLAVE_SN, DISCAPACIDAD, FECHA_ALTA,',
'FECHA_BAJA, TIPO_BAJA, TIPO_CONTRATO, EMP.CODIGO_CENTRO CODIGO_CENTRO, RANGOS_EDAD, DATO_VALIDO, PROVINCIA,',
'GRUPOS_CONTRATOS, GENERO_MF',
'from empleados emp',
'join CENTROS CTS on (CTS.CODIGO_CENTRO = EMP.CODIGO_CENTRO)',
'order by CODIGO_EMPLEADO'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572351200541343)
,p_query_column_id=>1
,p_column_alias=>'CODIGO_EMPLEADO'
,p_column_display_sequence=>10
,p_column_heading=>'Codigo Empleado'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572493274541344)
,p_query_column_id=>2
,p_column_alias=>'CATEG_PROFESIONAL'
,p_column_display_sequence=>20
,p_column_heading=>'Categ Profesional'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572503175541345)
,p_query_column_id=>3
,p_column_alias=>'PUESTO_TRABAJO'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572645533541346)
,p_query_column_id=>4
,p_column_alias=>'EDAD'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572777292541347)
,p_query_column_id=>5
,p_column_alias=>'CLAVE_SN'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572884076541348)
,p_query_column_id=>6
,p_column_alias=>'DISCAPACIDAD'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17572944158541349)
,p_query_column_id=>7
,p_column_alias=>'FECHA_ALTA'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17573027613541350)
,p_query_column_id=>8
,p_column_alias=>'FECHA_BAJA'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592141976558901)
,p_query_column_id=>9
,p_column_alias=>'TIPO_BAJA'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592225697558902)
,p_query_column_id=>10
,p_column_alias=>'TIPO_CONTRATO'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592331939558903)
,p_query_column_id=>11
,p_column_alias=>'CODIGO_CENTRO'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592576203558905)
,p_query_column_id=>12
,p_column_alias=>'RANGOS_EDAD'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592622241558906)
,p_query_column_id=>13
,p_column_alias=>'DATO_VALIDO'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17593769229558917)
,p_query_column_id=>14
,p_column_alias=>'PROVINCIA'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592750815558907)
,p_query_column_id=>15
,p_column_alias=>'GRUPOS_CONTRATOS'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17592817815558908)
,p_query_column_id=>16
,p_column_alias=>'GENERO_MF'
,p_column_display_sequence=>160
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31398701217607843)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(31398591527607843)
,p_landmark_label=>'Filters'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_10=>unistr('N\00FAmero de registros:')
,p_attribute_12=>'10000'
,p_attribute_13=>'E'
,p_attribute_14=>'#Dashboard'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31402278331607845)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13521013963287234)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17307165506754067)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(31402278331607845)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(13638064657287332)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:RR,6::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31406959729607855)
,p_name=>'P18_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Search'
,p_source=>'CODIGO_EMPLEADO,CATEG_PROFESIONAL,PUESTO_TRABAJO,CLAVE_SN,TIPO_BAJA,TIPO_CONTRATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_attribute_04=>'N'
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31407392952607856)
,p_name=>'P18_TIPO_CONTRATO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Tipo Contrato'
,p_source=>'TIPO_CONTRATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>true
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31407805434607856)
,p_name=>'P18_RANGOS_EDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Rangos Edad'
,p_source=>'RANGOS_EDAD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>true
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31408252412607856)
,p_name=>'P18_CATEG_PROFESIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Categ Profesional'
,p_source=>'CATEG_PROFESIONAL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_attribute_01=>'1'
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31408643410607856)
,p_name=>'P18_PUESTO_TRABAJO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Puesto Trabajo'
,p_source=>'PUESTO_TRABAJO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_attribute_01=>'1'
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31408976420607856)
,p_name=>'P18_GENERO_MF'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>unistr('G\00E9nero M/F')
,p_source=>'GENERO_MF'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31409798101607857)
,p_name=>'P18_CLAVE_SN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Clave S/N'
,p_source=>'CLAVE_SN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_attribute_05=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34541631585528269)
,p_name=>'P18_PROVINCIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(31398701217607843)
,p_prompt=>'Provincia'
,p_source=>'PROVINCIA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17593444427558914)
,p_name=>'Refrescar'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31398701217607843)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17593519587558915)
,p_event_id=>wwv_flow_imp.id(17593444427558914)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17238057328774213)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17594369933558923)
,p_event_id=>wwv_flow_imp.id(17593444427558914)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17593812907558918)
);
wwv_flow_imp.component_end;
end;
/
