prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'People Analytics'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#region_con_cards{',
'background: url(#APP_FILES#icons/quistor_logo_letras.png) no-repeat;',
'background-size: 20%;',
'background-position: right bottom;',
'}',
'',
'.my_card {',
'display:none',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240425154119'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13762216054287673)
,p_plug_name=>'People Analytics'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13541437840287243)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16885154596088801)
,p_plug_name=>'Indice'
,p_region_name=>'region_con_cards'
,p_region_template_options=>'#DEFAULT#:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(13525138661287237)
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(13461970027287120)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(13613799680287302)
);
wwv_flow_imp.component_end;
end;
/
