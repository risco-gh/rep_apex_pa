prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'TEST_JSON'
,p_alias=>'TEST-JSON'
,p_step_title=>'TEST_JSON'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.no_break {',
'  white-space: nowrap;',
'}',
'',
''))
,p_step_template=>wwv_flow_imp.id(13465178960287177)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240520155636'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(41016304023281661)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH test_data (json) AS',
'(',
unistr('---- 1   SELECT ''{"ListaEESSPrecio":[{"C.P.":"02250","Direcci\00F3n":"AVENIDA CASTILLA LA MANCHA, 26","Horario":"L-D: 07:00-22:00","Latitud":"39,211417","Localidad":"ABENGIBRE","Longitud (WGS84)":"-1,539167","Margen":"D","Municipio":"Abengibre","Precio B')
||unistr('iodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,379","Precio Gasoleo B":"1,059","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"')
||unistr('","Precio Gasolina 95 E5":"1,569","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"N\00BA 10.935","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ste')
||unistr('r met\00EDlico":"0,0","IDEESS":"4375","IDMunicipio":"52","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02152","Direcci\00F3n":"CR CM-332, 46,4","Horario":"L-D: 7:00-23:00","Latitud":"39,100389","Localidad":"ALATOZ","Longitud (WGS84)":"-1,346083","Margen":"I","M')
||unistr('unicipio":"Alatoz","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,689","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,729')
||unistr('","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,739","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"REPSOL","Tipo Venta":"P","%')
||unistr(' BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"5122","IDMunicipio":"53","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"CALLE FEDERICO GARCIA LORCA, 1","Horario":"L-D: 24H","Latitud":"39,000861","Localidad":"ALBACETE","Longitud (')
||unistr('WGS84)":"-1,849833","Margen":"D","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,389","Precio Gasoleo ')
||unistr('B":"","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,519","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tu')
||unistr('lo":"PLENOIL","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"13933","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"AVENIDA 1\00BA DE MAYO, S\005C/N","Horario":"L-S: 08:00-22:00; D: 09:00-21:00","Lat')
||'itud":"38,985667","Localidad":"ALBACETE","Longitud (WGS84)":"-1,868500","Margen":"N","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr'
||unistr('\00F3leo":"","Precio Gasoleo A":"1,529","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,589","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,679","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"1,799","Pre')
||unistr('cio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"CARREFOUR","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"10765","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"}]}'' FROM DUAL'),
'---- 2',
unistr('   SELECT ''[{"C.P.":"02250","Direcci\00F3n":"AVENIDA CASTILLA LA MANCHA, 26","Horario":"L-D: 07:00-22:00","Latitud":"39,211417","Localidad":"ABENGIBRE","Longitud (WGS84)":"-1,539167","Margen":"D","Municipio":"Abengibre","Precio Biodiesel":"","Precio Bioe')
||unistr('tanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,379","Precio Gasoleo B":"1,059","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5"')
||unistr(':"1,569","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"N\00BA 10.935","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS')
||unistr('":"4375","IDMunicipio":"52","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02152","Direcci\00F3n":"CR CM-332, 46,4","Horario":"L-D: 7:00-23:00","Latitud":"39,100389","Localidad":"ALATOZ","Longitud (WGS84)":"-1,346083","Margen":"I","Municipio":"Alatoz","Preci')
||unistr('o Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,689","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,729","Precio Gasolina 95 E10')
||unistr('":"","Precio Gasolina 95 E5":"1,739","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"REPSOL","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ste')
||unistr('r met\00EDlico":"0,0","IDEESS":"5122","IDMunicipio":"53","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"CALLE FEDERICO GARCIA LORCA, 1","Horario":"L-D: 24H","Latitud":"39,000861","Localidad":"ALBACETE","Longitud (WGS84)":"-1,849833","Marg')
||unistr('en":"D","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,389","Precio Gasoleo B":"","Precio Gasoleo Pre')
||unistr('mium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,519","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"PLENOIL","Tipo Venta')
||unistr('":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"13933","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"AVENIDA 1\00BA DE MAYO, S\005C/N","Horario":"L-S: 08:00-22:00; D: 09:00-21:00","Latitud":"38,985667","Locali')
||unistr('dad":"ALBACETE","Longitud (WGS84)":"-1,868500","Margen":"N","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo ')
||'A":"1,529","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,589","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,679","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"1,799","Precio Hidrogeno":"","Provin'
||unistr('cia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"CARREFOUR","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"10765","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"}]'' FROM DUAL'),
'--select :P29_NEW_1 from dual',
')',
'SELECT COD_POS, DIRECC',
'FROM test_data td,',
'JSON_TABLE(td.json, ',
'           ''$[*]'' ',
'           COLUMNS (row_number FOR ORDINALITY, ',
'                    COD_POS VARCHAR2 PATH ''$."C.P."'', ',
unistr('                    DIRECC VARCHAR2 PATH ''$."Direcci\00F3n"''))')))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20646963546874252)
,p_query_column_id=>1
,p_column_alias=>'COD_POS'
,p_column_display_sequence=>10
,p_column_heading=>'Cod Pos'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20647327892874252)
,p_query_column_id=>2
,p_column_alias=>'DIRECC'
,p_column_display_sequence=>20
,p_column_heading=>'Direcc'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59769020441956012)
,p_plug_name=>'Search Results'
,p_region_name=>'TABB'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13549541949287247)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>unistr('select sysdate FECHA, ''[{"C.P.":"02250","Direcci\00F3n":"AVENIDA CASTILLA LA MANCHA, 26","Horario":"L-D: 07:00-22:00","Latitud":"39,211417","Localidad":"ABENGIBRE","Longitud (WGS84)":"-1,539167","Margen":"D","Municipio":"Abengibre","Precio Biodiesel":"",')
||unistr('"Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,379","Precio Gasoleo B":"1,059","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gas')
||unistr('olina 95 E5":"1,569","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"N\00BA 10.935","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"')
||unistr('0,0","IDEESS":"4375","IDMunicipio":"52","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02152","Direcci\00F3n":"CR CM-332, 46,4","Horario":"L-D: 7:00-23:00","Latitud":"39,100389","Localidad":"ALATOZ","Longitud (WGS84)":"-1,346083","Margen":"I","Municipio":"Al')
||unistr('atoz","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,689","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,729","Precio Gas')
||unistr('olina 95 E10":"","Precio Gasolina 95 E5":"1,739","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"REPSOL","Tipo Venta":"P","% BioEtanol":"')
||unistr('0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"5122","IDMunicipio":"53","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"CALLE FEDERICO GARCIA LORCA, 1","Horario":"L-D: 24H","Latitud":"39,000861","Localidad":"ALBACETE","Longitud (WGS84)":"-1,8')
||unistr('49833","Margen":"D","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,389","Precio Gasoleo B":"","Precio')
||unistr(' Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,519","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"PLENOIL"')
||unistr(',"Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"13933","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"AVENIDA 1\00BA DE MAYO, S\005C/N","Horario":"L-S: 08:00-22:00; D: 09:00-21:00","Latitud":"38,985')
||unistr('667","Localidad":"ALBACETE","Longitud (WGS84)":"-1,868500","Margen":"N","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Pre')
||'cio Gasoleo A":"1,529","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,589","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,679","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"1,799","Precio Hidrogeno'
||unistr('":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"CARREFOUR","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"10765","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"}]'' DATA_LIST FROM DUAL')
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Search Results'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(20777189655941825)
,p_name=>'FECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(20777269690941826)
,p_name=>'DATA_LIST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATA_LIST'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Data List'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>3200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(20777084213941824)
,p_internal_uid=>20777084213941824
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(20859680031623741)
,p_interactive_grid_id=>wwv_flow_imp.id(20777084213941824)
,p_static_id=>'208597'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(20859831150623742)
,p_report_id=>wwv_flow_imp.id(20859680031623741)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(20860343818623751)
,p_view_id=>wwv_flow_imp.id(20859831150623742)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(20777189655941825)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(20861210645623759)
,p_view_id=>wwv_flow_imp.id(20859831150623742)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(20777269690941826)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59771436306956018)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13521013963287234)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20645878800874247)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(59771436306956018)
,p_button_name=>'RESET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(13638064657287332)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20775152340941805)
,p_name=>'P29_NEW_1'
,p_item_sequence=>40
,p_prompt=>'CAMPO'
,p_source=>'A'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59739914490683303)
,p_name=>'P29_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(59771436306956018)
,p_item_display_point=>'NEXT'
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('<b>\00DAltima actualizaci\00F3n</b>')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'to_char(sysdate, ''dd/mm/yyyy hh24:mi:ss'')||'' UTC''',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20777360489941827)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(59769020441956012)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20777499836941828)
,p_event_id=>wwv_flow_imp.id(20777360489941827)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var gridID = "TABB";',
'var ig$ = apex.region(gridID).widget();',
'var model   = ig$.interactiveGrid("getViews","grid").model;',
'',
'let pLine="";',
'let nLine="";',
'',
'',
'function getlinev(record) {',
'    var pFecha = model.getFieldKey("FECHA");',
'    var pData = model.getFieldKey("DATA_LIST");',
'',
'    let pfec = record[pFecha];',
'    let pdat = record[pData];',
'',
'    console.log("Fecha: " + pfec);',
'    console.log("Datos: " + pdat);',
'    return pdat;',
'};',
'',
'model.forEach(function(row) {',
'    let record = row;',
'    let line = getlinev(record);',
'//    console.log("Linea: " + line);',
'    pLine = pLine.concat(line);',
'    pLine = JSON.parse(pLine);',
'    nLine = pLine[1];',
'});',
'',
'apex.item("P29_NEW_1").setValue(nLine.Municipio);',
'//$.event.trigger(''ActualizarValor'')'))
);
wwv_flow_imp.component_end;
end;
/
