prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'Brecha Salarial Filtrada BVR'
,p_alias=>'BRECHA-SALARIAL-FILTRADA-BVR'
,p_step_title=>'Brecha Salarial Filtrada BVR'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(13465178960287177)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240405153652'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47453087488211803)
,p_plug_name=>'Brecha salarial por provincia'
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t2.provincia, centro, brecha_v, latitud, longitud from (select centro, to_char(round(gn_m/gn_f, 2),''90D99'') brecha_v from (',
'select t_emp.genero_mf genero, t_emp.codigo_centro centro, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' salarios t_sal ',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad)) and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT) ',
'  group by t_emp.codigo_centro, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))) t1',
'join centros t2 on t1.centro = t2.codigo_centro',
'join centros_geo t3 on t2.provincia = t3.provincia',
'where :P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(17537732654377079)
,p_region_id=>wwv_flow_imp.id(47453087488211803)
,p_height=>154
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(17538147402377080)
,p_map_region_id=>wwv_flow_imp.id(17537732654377079)
,p_name=>'Brecha por provincia'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_stroke_color=>'#0f0274'
,p_fill_color=>'#009dff'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'&BRECHA_V.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&PROVINCIA.: &BRECHA_V.<b/>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_PROVINCIA,P6_CATEG_PROFESIONAL,P6_RANGOS_EDAD:\&PROVINCIA.\,\&P24_CTGP.\,\&P24_RNGE.\'
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47453382748211806)
,p_plug_name=>'Brecha salarial y salario mensual (M/F)'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>80
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17539123458377082)
,p_region_id=>wwv_flow_imp.id(47453382748211806)
,p_chart_type=>'combo'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17541426277377083)
,p_chart_id=>wwv_flow_imp.id(17539123458377082)
,p_seq=>10
,p_name=>'Salario mensual M/F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t1.label as label, t1.series as series, decode(t1.series, ''F'', t1.value, ''M'', t1.value - t2.value) as value, color, t1.value valor from (',
'select mes as label, round(avg(salario_e), 0) as value,',
' genero_mf as series, decode(genero_mf, ''F'', ''#a274a7'', ''M'', ''#4857a7'') as color',
' from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''F'', ''M'') and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
')  group by mes, genero_mf) t1',
'join',
'(',
' select mes as label, round(avg(salario_e), 0) as value from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''F'') and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
') group by mes',
') t2 on (t2.label = t1.label)',
' order by label, value desc',
''))
,p_series_type=>'area'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_group_short_desc_column_name=>'VALOR'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'VALOR'
,p_color=>'&COLOR.'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17542070571377084)
,p_chart_id=>wwv_flow_imp.id(17539123458377082)
,p_seq=>20
,p_name=>'Brecha'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2) value, round(gn_m/gn_f, 2) valor from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios',
'  where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT) group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
' and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
' group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes',
'',
'',
''))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MES'
,p_items_short_desc_column_name=>'VALUE'
,p_color=>'#eeb807'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'on'
,p_items_label_rendered=>true
,p_items_label_position=>'belowMarker'
,p_items_label_font_family=>'Arial Black'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17539689816377082)
,p_chart_id=>wwv_flow_imp.id(17539123458377082)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>1400
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17540274911377083)
,p_chart_id=>wwv_flow_imp.id(17539123458377082)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_font_color=>'#f7b741'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17540876259377083)
,p_chart_id=>wwv_flow_imp.id(17539123458377082)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47718785698734698)
,p_plug_name=>unistr('Filtros de b\00FAsqueda')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61372196047000991)
,p_plug_name=>'Brecha salarial'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17513878008377058)
,p_region_id=>wwv_flow_imp.id(61372196047000991)
,p_chart_type=>'combo'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17515538308377059)
,p_chart_id=>wwv_flow_imp.id(17513878008377058)
,p_seq=>10
,p_name=>'Brecha salarial mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2),',
' /*case',
'    when to_number(:V_BRECHA_TOTAL) > 1.2 then :V_COLOR_YELLOW',
'    when to_number(:V_BRECHA_TOTAL) <= 1.2 AND to_number(:V_BRECHA_TOTAL) >= 0.8 then :V_COLOR_GREEN',
'    when to_number(:V_BRECHA_TOTAL) < 0.8 then :V_COLOR_RED',
' end a_color*/',
'    case',
'        when to_number(:V_BRECHA_TOTAL) < 0.5 then :V_COLOR_RED',
'        when to_number(:V_BRECHA_TOTAL) between 0.5 and 0.8 then :V_COLOR_YELLOW',
'        when to_number(:V_BRECHA_TOTAL) between 0.8 and 1.2 then :V_COLOR_GREEN',
'        when to_number(:V_BRECHA_TOTAL) > 1.5 then :V_COLOR_RED',
'        when to_number(:V_BRECHA_TOTAL) between 1.2 and 1.5 then :V_COLOR_YELLOW',
'--        else :V_COLOR_YELLOW',
'    end a_color',
' from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios',
'  where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT) group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and',
'  (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad)) and',
'  (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes'))
,p_series_type=>'area'
,p_items_value_column_name=>'ROUND(GN_M/GN_F,2)'
,p_items_label_column_name=>'MES'
,p_items_short_desc_column_name=>'ROUND(GN_M/GN_F,2)'
,p_color=>'&A_COLOR.'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17514329010377058)
,p_chart_id=>wwv_flow_imp.id(17513878008377058)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17514937690377059)
,p_chart_id=>wwv_flow_imp.id(17513878008377058)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61836898350584994)
,p_plug_name=>'Brecha salarial anual'
,p_parent_plug_id=>wwv_flow_imp.id(61372196047000991)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''label'' as label, to_char(round(gn_m/gn_f, 2),''90D99'') value, null as pct from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad)) and',
'  (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  and to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_landmark_type=>'exclude_landmark'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61595776330203802)
,p_plug_name=>'Salario mensual masculino'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17516916328377061)
,p_region_id=>wwv_flow_imp.id(61595776330203802)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17518603730377062)
,p_chart_id=>wwv_flow_imp.id(17516916328377061)
,p_seq=>10
,p_name=>'Salario mensual masculino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional)))',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_items_label_column_name=>'MES'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17517423178377061)
,p_chart_id=>wwv_flow_imp.id(17516916328377061)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17518016848377061)
,p_chart_id=>wwv_flow_imp.id(17516916328377061)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61837055628584995)
,p_plug_name=>'Salario masculino anual'
,p_parent_plug_id=>wwv_flow_imp.id(61595776330203802)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ''Salario M'' as label, round(avg(salario_e), 0) as value, null as pct from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT) and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
' ',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61596313004203807)
,p_plug_name=>'Salario mensual femenino'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17520068755377063)
,p_region_id=>wwv_flow_imp.id(61596313004203807)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17521750758377064)
,p_chart_id=>wwv_flow_imp.id(17520068755377063)
,p_seq=>10
,p_name=>'Salario mensual femenino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and dato_valido = ''S'' and to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
' )',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_items_label_column_name=>'MES'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17520599087377063)
,p_chart_id=>wwv_flow_imp.id(17520068755377063)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17521101228377064)
,p_chart_id=>wwv_flow_imp.id(17520068755377063)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61837169245584996)
,p_plug_name=>'Salario femenino anual'
,p_parent_plug_id=>wwv_flow_imp.id(61596313004203807)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Salario F'' as label, round(avg(salario_e), 0) as value, null as pct from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and to_char(mm_yyyy, ''YYYY'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT) and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61837832416585003)
,p_plug_name=>'Salario mensual (F/M) por trimestre'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>90
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17510570427377049)
,p_region_id=>wwv_flow_imp.id(61837832416585003)
,p_chart_type=>'boxPlot'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17512824893377057)
,p_chart_id=>wwv_flow_imp.id(17510570427377049)
,p_seq=>10
,p_name=>'Salario F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where',
'   dato_valido = ''S'' and genero_mf = ''F''',
'   and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'   and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado',
''))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:CR,13:IG_GENERO_MF,IG_CODIGO_EMPLEADO:F,\&EMPLEADO.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17512265344377056)
,p_chart_id=>wwv_flow_imp.id(17510570427377049)
,p_seq=>20
,p_name=>'Salario M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where',
'   dato_valido = ''S'' and genero_mf = ''M''',
'   and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'   and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado',
'',
''))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17511012312377051)
,p_chart_id=>wwv_flow_imp.id(17510570427377049)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17511675351377054)
,p_chart_id=>wwv_flow_imp.id(17510570427377049)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61839599501585021)
,p_plug_name=>'Salario por rango de edad'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61838404068585009)
,p_plug_name=>'Brecha salarial por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(61839599501585021)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17523577603377066)
,p_region_id=>wwv_flow_imp.id(61838404068585009)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17525211414377067)
,p_chart_id=>wwv_flow_imp.id(17523577603377066)
,p_seq=>10
,p_name=>'Brecha por rango edad'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rango_e label, round(gn_m/gn_f, 2) value from (',
'select t_emp.genero_mf genero, t_emp.rangos_edad rango_e,',
' round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f)) order by rango_e',
''))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_RANGOS_EDAD,P6_CATEG_PROFESIONAL:\&LABEL.\,\&P24_CTGP.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17525852070377068)
,p_chart_id=>wwv_flow_imp.id(17523577603377066)
,p_seq=>20
,p_name=>'Valor objetivo'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct rangos_edad label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17524061646377067)
,p_chart_id=>wwv_flow_imp.id(17523577603377066)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17524634765377067)
,p_chart_id=>wwv_flow_imp.id(17523577603377066)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61839756933585022)
,p_plug_name=>'Salario M/F por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(61839599501585021)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17526807600377069)
,p_region_id=>wwv_flow_imp.id(61839756933585022)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17529798338377071)
,p_chart_id=>wwv_flow_imp.id(17526807600377069)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad order by rangos_edad',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_GENERO_MF,P6_RANGOS_EDAD,P6_CATEG_PROFESIONAL:&GENERO.,&RANGO_E.,\&P24_CTGP.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17529137487377071)
,p_chart_id=>wwv_flow_imp.id(17526807600377069)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad order by rangos_edad',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_GENERO_MF,P6_RANGOS_EDAD,P6_CATEG_PROFESIONAL:&GENERO.,&RANGO_E.,\&P24_CTGP.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17527326365377069)
,p_chart_id=>wwv_flow_imp.id(17526807600377069)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17527928450377070)
,p_chart_id=>wwv_flow_imp.id(17526807600377069)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17528504400377070)
,p_chart_id=>wwv_flow_imp.id(17526807600377069)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62329378713214181)
,p_plug_name=>unistr('Salario por categor\00EDa profesional')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62329553459214182)
,p_plug_name=>unistr('Brecha salarial por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(62329378713214181)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17531115872377073)
,p_region_id=>wwv_flow_imp.id(62329553459214182)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17532882022377074)
,p_chart_id=>wwv_flow_imp.id(17531115872377073)
,p_seq=>10
,p_name=>unistr('Brecha por categor\00EDa')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select categ, decode(gn_f, 0, 0, round(gn_m/gn_f, 2)) from (',
'select t_emp.genero_mf genero, t_emp.categ_profesional categ, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S'' ',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional, t_emp.genero_mf',
')',
'pivot (sum(decode(nvl(num_e, 0), 0, 0, salario_e/num_e)) for genero in (''M'' gn_m, ''F'' gn_f)) order by categ',
''))
,p_series_type=>'bar'
,p_items_value_column_name=>'DECODE(GN_F,0,0,ROUND(GN_M/GN_F,2))'
,p_items_label_column_name=>'CATEG'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_CATEG_PROFESIONAL,P6_RANGOS_EDAD:&CATEG.,\&P24_RNGE.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17533463037377074)
,p_chart_id=>wwv_flow_imp.id(17531115872377073)
,p_seq=>20
,p_name=>'Valor objetivo'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct categ_profesional label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17531685758377073)
,p_chart_id=>wwv_flow_imp.id(17531115872377073)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17532276718377073)
,p_chart_id=>wwv_flow_imp.id(17531115872377073)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62329583195214183)
,p_plug_name=>unistr('Salario M/F por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(62329378713214181)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17534418336377075)
,p_region_id=>wwv_flow_imp.id(62329583195214183)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17536100033377076)
,p_chart_id=>wwv_flow_imp.id(17534418336377075)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf  = ''F'' and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_CATEG_PROFESIONAL,P6_GENERO_MF,P6_RANGOS_EDAD:&CATEG.,&GENERO.,\&P24_RNGE.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17536775696377077)
,p_chart_id=>wwv_flow_imp.id(17534418336377075)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf  = ''M'' and dato_valido = ''S''',
'  and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad))',
'  and (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_CATEG_PROFESIONAL,P6_GENERO_MF,P6_RANGOS_EDAD:&CATEG.,&GENERO.,\&P24_RNGE.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17534949313377076)
,p_chart_id=>wwv_flow_imp.id(17534418336377075)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17535567638377076)
,p_chart_id=>wwv_flow_imp.id(17534418336377075)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34097002011971668)
,p_name=>'P24_YEAR'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(47718785698734698)
,p_item_default=>'V_YEAR_DEFAULT'
,p_item_default_type=>'ITEM'
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s_year s_year1, s_year s_year2 from (',
'select distinct to_char(mm_yyyy, ''yyyy'') s_year, to_number(to_char(mm_yyyy, ''yyyy'')) n_year',
' from salarios',
' )',
' order by n_year desc'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47733649834734746)
,p_name=>'P24_PROV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(47718785698734698)
,p_prompt=>'Provincia'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select distinct provincia p1, provincia p2 from centros'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47733946685734749)
,p_name=>'P24_CTGP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(47718785698734698)
,p_prompt=>unistr('Categor\00EDa profesional')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select distinct categ_profesional ct1, categ_profesional ct2 from empleados order by categ_profesional'
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47734312740734752)
,p_name=>'P24_RNGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(47718785698734698)
,p_prompt=>'Rango de edad'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rangos_edad rn1, rangos_edad rn2 from (',
'select rangos_edad, nord from (',
'select distinct rangos_edad,',
' case',
'   when rangos_edad = ''Sin Edad'' then 1',
'   when rangos_edad = ''16-25'' then 2',
'   when rangos_edad = ''26-35'' then 3',
'   when rangos_edad = ''36-45'' then 4',
'   when rangos_edad = ''46-55'' then 5',
'   when rangos_edad = ''> 55'' then 6',
' end nord',
'from empleados) order by nord)'))
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(17542935334377085)
,p_computation_sequence=>10
,p_computation_item=>'V_BRECHA_TOTAL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select round(gn_m/gn_f, 2) from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P24_PROV is null or REGEXP_LIKE(:P24_PROV, t2.provincia)) and (:P24_RNGE is null or REGEXP_LIKE(:P24_RNGE, t_emp.rangos_edad)) and',
'  (:P24_CTGP is null or REGEXP_LIKE(:P24_CTGP, t_emp.categ_profesional))',
'  and to_char(mm_yyyy, ''yyyy'') = nvl(:P24_YEAR, :V_YEAR_DEFAULT)',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17543269776377086)
,p_name=>'DA_PROV'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_PROV'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17543709890377087)
,p_event_id=>wwv_flow_imp.id(17543269776377086)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17544185408377087)
,p_name=>'DA_CTGP'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_CTGP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17544674637377088)
,p_event_id=>wwv_flow_imp.id(17544185408377087)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17545024427377088)
,p_name=>'DA_RNGE'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_RNGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17545531314377088)
,p_event_id=>wwv_flow_imp.id(17545024427377088)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
