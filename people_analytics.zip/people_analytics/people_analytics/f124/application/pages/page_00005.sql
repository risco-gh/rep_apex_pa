prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'TEST PRISA'
,p_alias=>'TEST-PRISA'
,p_step_title=>'TEST PRISA'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'require(["ojs/ojtagcloud"] , function() {});'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.green {',
'    fill: url(#fancy_green);',
'}',
'',
'.tBorder {',
'  border-width: var(--ut-component-border-width);',
'  border-style: solid;',
'  border-color: var(--ut-component-border-color);',
'  border-radius: var(--ut-component-border-radius);',
'  box-shadow: var(--ut-component-box-shadow);',
'  background-color: var(--ut-component-background-color);',
'  color: var(--ut-component-text-default-color);',
'  padding: 20px;',
'  margin: auto;',
'  max-width: 320px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240320143145'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30804217246400443)
,p_plug_name=>'Absentismo por mes en 2021'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15766765424720038)
,p_region_id=>wwv_flow_imp.id(30804217246400443)
,p_chart_type=>'line'
,p_height=>'120'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15768432957720039)
,p_chart_id=>wwv_flow_imp.id(15766765424720038)
,p_seq=>10
,p_name=>'Absentismo mensual'
,p_data_source_type=>'SQL'
,p_data_source=>'select to_char(mes, ''Mon'') label, to_char(mes, ''Mon'') mes_c, round(sum(nvl(n_dias, 0)), 2) dias_m from ABSENTISMO where to_char(MES, ''YYYY'') = ''2021'' group by mes order by mes'
,p_items_value_column_name=>'DIAS_M'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'DIAS_M'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15767264403720038)
,p_chart_id=>wwv_flow_imp.id(15766765424720038)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15767895733720038)
,p_chart_id=>wwv_flow_imp.id(15766765424720038)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>unistr('N\00BA D\00EDas')
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31409021244568601)
,p_plug_name=>'Dummy1'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30803076337400432)
,p_plug_name=>'% Absentismo'
,p_parent_plug_id=>wwv_flow_imp.id(31409021244568601)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Absentismo total'' label,',
'to_char(round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100)||''%'' value, null pct from (',
'select count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021'' group by mes order by mes',
')',
't1) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by dias_abs, n_meses)'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30804036828400442)
,p_plug_name=>unistr('D\00EDas totales de ausencias')
,p_parent_plug_id=>wwv_flow_imp.id(31409021244568601)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('select ''D\00EDas totales'', round(sum(nvl(n_dias, 0)),0) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021''')
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'DIAS_M'
,p_attribute_05=>'0'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31409669586568608)
,p_plug_name=>'Dummy2'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>90
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15650275778848619)
,p_plug_name=>'PRISA - PIE 1'
,p_parent_plug_id=>wwv_flow_imp.id(31409669586568608)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select tipo_absentismo, sum(n_dias) from absentismo where to_char(mes, ''yyyy'') = ''2021'' group by tipo_absentismo'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15650362035848620)
,p_region_id=>wwv_flow_imp.id(15650275778848619)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'explode'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'    options.pieSliceExplode = "1"',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15650452892848621)
,p_chart_id=>wwv_flow_imp.id(15650362035848620)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SUM(N_DIAS)'
,p_items_label_column_name=>'TIPO_ABSENTISMO'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31408724153568598)
,p_plug_name=>unistr('Absentismo por regi\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(31409669586568608)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(15764097231720031)
,p_region_id=>wwv_flow_imp.id(31408724153568598)
,p_height=>400
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'5'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(15764529376720032)
,p_map_region_id=>wwv_flow_imp.id(15764097231720031)
,p_name=>'Absentismo'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
't2.comunidad, round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 n_dias,',
'to_char(round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100)||''%'' pc_dias',
', geometry',
'from (',
'select codigo_centro, count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_centro, codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select codigo_centro, sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select codigo_centro, mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021'' group by codigo_centro, mes order by mes',
')',
't1',
' group by codigo_centro) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by codigo_centro, dias_abs, n_meses) t3',
'join centros t2 on t2.codigo_centro = t3.codigo_centro',
'join map_comunidades t4 on t4.name = t2.comunidad'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'TealGrn'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'N_DIAS'
,p_fill_opacity=>.5
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&COMUNIDAD.: &PC_DIAS.</b>'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31409093085568602)
,p_plug_name=>'PRISA - BAR 1'
,p_region_name=>'fancy'
,p_parent_plug_id=>wwv_flow_imp.id(31409669586568608)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15935982721981155)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select tipo_absentismo, sum(n_dias) from absentismo where to_char(mes, ''yyyy'') = ''2021'' group by tipo_absentismo'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15761404251720025)
,p_region_id=>wwv_flow_imp.id(31409093085568602)
,p_chart_type=>'bar'
,p_title=>'Title'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'    options.dataFilter = function( data ) {',
'        for (var i=0; i<data.series.length; i++){',
'            data.series[i].className = ''green'';',
'        };',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15763074463720029)
,p_chart_id=>wwv_flow_imp.id(15761404251720025)
,p_seq=>10
,p_name=>'Absentismo por motivo'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SUM(N_DIAS)'
,p_items_label_column_name=>'TIPO_ABSENTISMO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15761916474720026)
,p_chart_id=>wwv_flow_imp.id(15761404251720025)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15762436587720028)
,p_chart_id=>wwv_flow_imp.id(15761404251720025)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15769285052720054)
,p_name=>'Add Gradients'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31409093085568602)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15769723249720057)
,p_event_id=>wwv_flow_imp.id(15769285052720054)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Green'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Get the chart element',
'const chart = document.getElementById("fancy");',
'// Create a new linearGradient element',
'const gradient = document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");',
'gradient.setAttribute("id", "fancy_green");',
'gradient.setAttribute("gradientTransform", "rotate(90)");',
'// Create two stop elements and add them to the gradient',
'const stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop");',
'stop1.setAttribute("offset", "5%");',
'stop1.setAttribute("stop-color", "#35aff1");',
'gradient.appendChild(stop1);',
'const stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop");',
'stop2.setAttribute("offset", "95%");',
'stop2.setAttribute("stop-color", "#0d8d02");',
'gradient.appendChild(stop2);',
'// Get the defs element that is a child of the chart element',
'const defs = chart.querySelector("defs");',
'// Add the gradient element as a child of the defs element',
'defs.appendChild(gradient);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15651395222848630)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15650275778848619)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15651464079848631)
,p_event_id=>wwv_flow_imp.id(15651395222848630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-chart-series',
'                  pie-slice-explode=''[[ series.id == "Series 5" ?  pieSliceExplode : 0 ]]''></oj-chart-series>'))
);
wwv_flow_imp.component_end;
end;
/
