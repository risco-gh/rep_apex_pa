prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Brecha Salarial Filtrada'
,p_alias=>'BRECHA-SALARIAL-FILTRADA'
,p_step_title=>'Brecha Salarial Filtrada'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function hideRegion(ID1, ID2) {',
'    $(ID1).hide();',
'    $(ID2).parent().removeClass( "col-10" );',
'    $(ID2).parent().addClass( "col-12 ");',
'    $(bhide_b).hide();',
'    $(bshow_b).show();',
'}',
'',
'function showRegion(ID1, ID2) {',
'    $(ID1).show();',
'    $(ID2).parent().removeClass( "col-12" );',
'    $(ID2).parent().addClass( "col-10 ");',
'    $(bhide_b).show();',
'    $(bshow_b).hide();',
'}'))
,p_javascript_code_onload=>'$(bshow_b).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:40px;',
'  height:40px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: rgba(231, 227, 204, 0.342);',
'  color:rgb(7, 7, 7);',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'    top:18%;',
'    left:1%;',
'}'))
,p_step_template=>wwv_flow_imp.id(13472524453287181)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240507085904'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16588910489594635)
,p_plug_name=>'Filtros'
,p_region_name=>'filter_r'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-left-none'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16589027552594636)
,p_plug_name=>'Charts'
,p_region_name=>'charts_r'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_column=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63988941001825158)
,p_plug_name=>'Brecha salarial por provincia'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t2.provincia, centro, brecha_v, latitud, longitud from (select centro, to_char(round(gn_m/gn_f, 2),''90D99'') brecha_v from (',
'select t_emp.genero_mf genero, t_emp.codigo_centro centro, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' salarios t_sal ',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad)) and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT) ',
'  group by t_emp.codigo_centro, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))) t1',
'join centros t2 on t1.centro = t2.codigo_centro',
'join centros_geo t3 on t2.provincia = t3.provincia',
'where :P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(17080364736756757)
,p_region_id=>wwv_flow_imp.id(63988941001825158)
,p_height=>154
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
,p_copyright_notice=>' '
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(17080897891756757)
,p_map_region_id=>wwv_flow_imp.id(17080364736756757)
,p_name=>'Brecha por provincia'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_stroke_color=>'#0f0274'
,p_fill_color=>'#009dff'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'&BRECHA_V.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&PROVINCIA.: &BRECHA_V.<b/>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_PROVINCIA:&PROVINCIA.'
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63989236261825161)
,p_plug_name=>'Brecha salarial y salario mensual (M/F)'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17096434205756767)
,p_region_id=>wwv_flow_imp.id(63989236261825161)
,p_chart_type=>'combo'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'end'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17098759535756768)
,p_chart_id=>wwv_flow_imp.id(17096434205756767)
,p_seq=>10
,p_name=>'Salario mensual M/F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t1.label as label, t1.series as series, decode(t1.series, ''F'', t1.value, ''M'', t1.value - t2.value) as value, color, t1.value valor from (',
'select mes as label, round(avg(salario_e), 0) as value,',
' genero_mf as series, decode(genero_mf, ''F'', ''#a274a7'', ''M'', ''#4857a7'') as color',
' from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''F'', ''M'') and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
')  group by mes, genero_mf) t1',
'join',
'(',
' select mes as label, round(avg(salario_e), 0) as value from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''F'') and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P8_YEAR, :V_YEAR_DEFAULT)',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
') group by mes',
') t2 on (t2.label = t1.label)',
' order by label, value desc',
''))
,p_series_type=>'area'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_group_short_desc_column_name=>'VALOR'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'VALOR'
,p_color=>'&COLOR.'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17099376992756769)
,p_chart_id=>wwv_flow_imp.id(17096434205756767)
,p_seq=>20
,p_name=>'Brecha'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2) value, round(gn_m/gn_f, 2) valor from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios',
'  where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT) group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
' and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
' group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes',
'',
'',
''))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MES'
,p_items_short_desc_column_name=>'VALUE'
,p_color=>'#eeb807'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'on'
,p_items_label_rendered=>true
,p_items_label_position=>'belowMarker'
,p_items_label_font_family=>'Arial Black'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17096900255756767)
,p_chart_id=>wwv_flow_imp.id(17096434205756767)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>1400
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17097540331756768)
,p_chart_id=>wwv_flow_imp.id(17096434205756767)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_font_color=>'#f7b741'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17098166819756768)
,p_chart_id=>wwv_flow_imp.id(17096434205756767)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77908049560614346)
,p_plug_name=>'Brecha salarial'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17071003517756747)
,p_region_id=>wwv_flow_imp.id(77908049560614346)
,p_chart_type=>'combo'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17072794033756750)
,p_chart_id=>wwv_flow_imp.id(17071003517756747)
,p_seq=>10
,p_name=>'Brecha salarial mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2),',
'    case',
'        when to_number(:V_BRECHA_TOTAL) < 0.5 then :V_COLOR_RED',
'        when to_number(:V_BRECHA_TOTAL) between 0.5 and 0.8 then :V_COLOR_YELLOW',
'        when to_number(:V_BRECHA_TOTAL) between 0.8 and 1.2 then :V_COLOR_GREEN',
'        when to_number(:V_BRECHA_TOTAL) > 1.5 then :V_COLOR_RED',
'        when to_number(:V_BRECHA_TOTAL) between 1.2 and 1.5 then :V_COLOR_YELLOW',
'    end a_color',
' from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios',
'  where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT) group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and',
'  (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad)) and',
'  (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes'))
,p_series_type=>'area'
,p_items_value_column_name=>'ROUND(GN_M/GN_F,2)'
,p_items_label_column_name=>'MES'
,p_color=>'&A_COLOR.'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17072183944756747)
,p_chart_id=>wwv_flow_imp.id(17071003517756747)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17071502123756747)
,p_chart_id=>wwv_flow_imp.id(17071003517756747)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78372751864198349)
,p_plug_name=>'Brecha salarial anual'
,p_parent_plug_id=>wwv_flow_imp.id(77908049560614346)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''label'' as label, to_char(round(gn_m/gn_f, 2),''90D99'') value, null as pct from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad)) and',
'  (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  and to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_landmark_type=>'exclude_landmark'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78131629843817157)
,p_plug_name=>'Salario mensual masculino'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17074107000756752)
,p_region_id=>wwv_flow_imp.id(78131629843817157)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17075832057756753)
,p_chart_id=>wwv_flow_imp.id(17074107000756752)
,p_seq=>10
,p_name=>'Salario mensual masculino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and dato_valido = ''S'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional)))',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_items_label_column_name=>'MES'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17074615462756753)
,p_chart_id=>wwv_flow_imp.id(17074107000756752)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17075211912756753)
,p_chart_id=>wwv_flow_imp.id(17074107000756752)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78372909142198350)
,p_plug_name=>'Salario masculino anual'
,p_parent_plug_id=>wwv_flow_imp.id(78131629843817157)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ''Salario M'' as label, round(avg(salario_e), 0) as value, null as pct from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and to_char(t_sal.mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT) and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
' ',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78132166517817162)
,p_plug_name=>'Salario mensual femenino'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17077250175756754)
,p_region_id=>wwv_flow_imp.id(78132166517817162)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17078933176756755)
,p_chart_id=>wwv_flow_imp.id(17077250175756754)
,p_seq=>10
,p_name=>'Salario mensual femenino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and dato_valido = ''S'' and to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
' )',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_items_label_column_name=>'MES'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17077724384756755)
,p_chart_id=>wwv_flow_imp.id(17077250175756754)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17078330543756755)
,p_chart_id=>wwv_flow_imp.id(17077250175756754)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78373022759198351)
,p_plug_name=>'Salario femenino anual'
,p_parent_plug_id=>wwv_flow_imp.id(78132166517817162)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Salario F'' as label, round(avg(salario_e), 0) as value, null as pct from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and to_char(mm_yyyy, ''YYYY'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT) and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78373685930198358)
,p_plug_name=>'Salario mensual (F/M) por trimestre'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17067748566756744)
,p_region_id=>wwv_flow_imp.id(78373685930198358)
,p_chart_type=>'boxPlot'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17070068306756746)
,p_chart_id=>wwv_flow_imp.id(17067748566756744)
,p_seq=>10
,p_name=>'Salario F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where',
'   dato_valido = ''S'' and genero_mf = ''F''',
'   and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'   and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado',
''))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17069421938756745)
,p_chart_id=>wwv_flow_imp.id(17067748566756744)
,p_seq=>20
,p_name=>'Salario M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where',
'   dato_valido = ''S'' and genero_mf = ''M''',
'   and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'   and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado',
'',
''))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17068246123756744)
,p_chart_id=>wwv_flow_imp.id(17067748566756744)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17068881618756745)
,p_chart_id=>wwv_flow_imp.id(17067748566756744)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78375453015198376)
,p_plug_name=>'Salario por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78374257582198364)
,p_plug_name=>'Brecha salarial por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(78375453015198376)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17082279937756758)
,p_region_id=>wwv_flow_imp.id(78374257582198364)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17083944595756759)
,p_chart_id=>wwv_flow_imp.id(17082279937756758)
,p_seq=>10
,p_name=>'Brecha por rango edad'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rango_e label, round(gn_m/gn_f, 2) value from (',
'select t_emp.genero_mf genero, t_emp.rangos_edad rango_e,',
' round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f)) order by rango_e',
''))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_RANGOS_EDAD:\&LABEL.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17084568114756759)
,p_chart_id=>wwv_flow_imp.id(17082279937756758)
,p_seq=>20
,p_name=>'Valor objetivo'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct rangos_edad label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17082714880756758)
,p_chart_id=>wwv_flow_imp.id(17082279937756758)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17083334899756759)
,p_chart_id=>wwv_flow_imp.id(17082279937756758)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78375610447198377)
,p_plug_name=>'Salario M/F por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(78375453015198376)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17085529414756760)
,p_region_id=>wwv_flow_imp.id(78375610447198377)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17088422744756762)
,p_chart_id=>wwv_flow_imp.id(17085529414756760)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''F'' and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad order by rangos_edad',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_GENERO_MF,P6_RANGOS_EDAD:&GENERO.,&RANGO_E.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17087849894756761)
,p_chart_id=>wwv_flow_imp.id(17085529414756760)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf = ''M'' and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.rangos_edad order by rangos_edad',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_GENERO_MF,P6_RANGOS_EDAD:&GENERO.,&RANGO_E.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17086051606756760)
,p_chart_id=>wwv_flow_imp.id(17085529414756760)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17086637764756761)
,p_chart_id=>wwv_flow_imp.id(17085529414756760)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17087236587756761)
,p_chart_id=>wwv_flow_imp.id(17085529414756760)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78865232226827536)
,p_plug_name=>unistr('Salario por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(16589027552594636)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78865406972827537)
,p_plug_name=>unistr('Brecha salarial por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(78865232226827536)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17089831137756763)
,p_region_id=>wwv_flow_imp.id(78865406972827537)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17091540054756764)
,p_chart_id=>wwv_flow_imp.id(17089831137756763)
,p_seq=>10
,p_name=>unistr('Brecha por categor\00EDa')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select categ, decode(gn_f, 0, 0, round(gn_m/gn_f, 2)) from (',
'select t_emp.genero_mf genero, t_emp.categ_profesional categ, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S'' ',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional, t_emp.genero_mf',
')',
'pivot (sum(decode(nvl(num_e, 0), 0, 0, salario_e/num_e)) for genero in (''M'' gn_m, ''F'' gn_f)) order by categ',
''))
,p_series_type=>'bar'
,p_items_value_column_name=>'DECODE(GN_F,0,0,ROUND(GN_M/GN_F,2))'
,p_items_label_column_name=>'CATEG'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_CATEG_PROFESIONAL:\&CATEG.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17092134609756764)
,p_chart_id=>wwv_flow_imp.id(17089831137756763)
,p_seq=>20
,p_name=>'Valor objetivo'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct categ_profesional label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17090338055756763)
,p_chart_id=>wwv_flow_imp.id(17089831137756763)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17090913832756763)
,p_chart_id=>wwv_flow_imp.id(17089831137756763)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78865436708827538)
,p_plug_name=>unistr('Salario M/F por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(78865232226827536)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17093166142756765)
,p_region_id=>wwv_flow_imp.id(78865436708827538)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17094880601756766)
,p_chart_id=>wwv_flow_imp.id(17093166142756765)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf  = ''F'' and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_CATEG_PROFESIONAL,P6_GENERO_MF:&CATEG.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17095459503756766)
,p_chart_id=>wwv_flow_imp.id(17093166142756765)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios where to_char(mm_yyyy, ''yyyy'') = nvl(:P16_YEAR, :V_YEAR_DEFAULT)) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf  = ''M'' and dato_valido = ''S''',
'  and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad))',
'  and (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.categ_profesional',
''))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_CATEG_PROFESIONAL,P6_GENERO_MF:&CATEG.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17093687952756765)
,p_chart_id=>wwv_flow_imp.id(17093166142756765)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17094275356756765)
,p_chart_id=>wwv_flow_imp.id(17093166142756765)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17236901850774202)
,p_plug_name=>'FHide'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-none:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>2
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16589137278594637)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17236901850774202)
,p_button_name=>'BHide'
,p_button_static_id=>'bhide_b'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(13637276681287327)
,p_button_image_alt=>'Ocultar filtros'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-angle-double-left'
,p_grid_new_row=>'Y'
,p_grid_column=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16589485769594640)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17236901850774202)
,p_button_name=>'BShow'
,p_button_static_id=>'bshow_b'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(13637276681287327)
,p_button_image_alt=>'Mostrar filtros'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-angle-double-right'
,p_grid_new_row=>'N'
,p_grid_column=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50633489215585038)
,p_name=>'P16_YEAR'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16588910489594635)
,p_item_default=>'V_YEAR_DEFAULT'
,p_item_default_type=>'ITEM'
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s_year s_year1, s_year s_year2 from (',
'select distinct to_char(mm_yyyy, ''yyyy'') s_year, to_number(to_char(mm_yyyy, ''yyyy'')) n_year',
' from salarios',
' )',
' order by n_year desc'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64270137038348116)
,p_name=>'P16_PROV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16588910489594635)
,p_prompt=>'Provincia'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select distinct provincia p1, provincia p2 from centros'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64270433889348119)
,p_name=>'P16_CTGP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(16588910489594635)
,p_prompt=>unistr('Categor\00EDa profesional')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select distinct categ_profesional ct1, categ_profesional ct2 from empleados'
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64270799944348122)
,p_name=>'P16_RNGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16588910489594635)
,p_prompt=>'Rango de edad'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rangos_edad rn1, rangos_edad rn2 from (',
'select rangos_edad, nord from (',
'select distinct rangos_edad,',
' case',
'   when rangos_edad = ''Sin Edad'' then 1',
'   when rangos_edad = ''16-25'' then 2',
'   when rangos_edad = ''26-35'' then 3',
'   when rangos_edad = ''36-45'' then 4',
'   when rangos_edad = ''46-55'' then 5',
'   when rangos_edad = ''> 55'' then 6',
' end nord',
'from empleados) order by nord)'))
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(17100260986756770)
,p_computation_sequence=>10
,p_computation_item=>'V_BRECHA_TOTAL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select round(gn_m/gn_f, 2) from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
'  salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' join centros t2 on t_emp.codigo_centro = t2.codigo_centro',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
' and (:P16_PROV is null or REGEXP_LIKE(:P16_PROV, t2.provincia)) and (:P16_RNGE is null or REGEXP_LIKE(:P16_RNGE, t_emp.rangos_edad)) and',
'  (:P16_CTGP is null or REGEXP_LIKE(:P16_CTGP, t_emp.categ_profesional))',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17100524065756770)
,p_name=>'DA_PROV'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P16_PROV'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17101000175756771)
,p_event_id=>wwv_flow_imp.id(17100524065756770)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17101433596756771)
,p_name=>'DA_CTGP'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P16_CTGP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17101970595756771)
,p_event_id=>wwv_flow_imp.id(17101433596756771)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17102365525756771)
,p_name=>'DA_RNGE'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P16_RNGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17102880751756772)
,p_event_id=>wwv_flow_imp.id(17102365525756771)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16589228659594638)
,p_name=>'b_hide'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16589137278594637)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16589332364594639)
,p_event_id=>wwv_flow_imp.id(16589228659594638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'hideRegion(''#filter_r'',''#charts_r'');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16590362592594649)
,p_name=>'b_show'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16589485769594640)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16590481379594650)
,p_event_id=>wwv_flow_imp.id(16590362592594649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'showRegion(''#filter_r'',''#charts_r'');'
);
wwv_flow_imp.component_end;
end;
/
