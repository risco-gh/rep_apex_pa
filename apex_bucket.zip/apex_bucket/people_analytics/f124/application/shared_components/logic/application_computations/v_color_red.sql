prompt --application/shared_components/logic/application_computations/v_color_red
begin
--   Manifest
--     APPLICATION COMPUTATION: V_COLOR_RED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(16878747161007760)
,p_computation_sequence=>10
,p_computation_item=>'V_COLOR_RED'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'rgba(225, 0, 0, 0.75)'
,p_version_scn=>41261317434767
);
wwv_flow_imp.component_end;
end;
/
