prompt --workspace/remote_servers/data_api_ecb_europa_eu
begin
--   Manifest
--     REMOTE SERVER: data-api.ecb.europa.eu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(18621713059078115)
,p_name=>'data-api.ecb.europa.eu'
,p_static_id=>'data_api_ecb_europa_eu'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('data_api_ecb_europa_eu'),'https://data-api.ecb.europa.eu/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('data_api_ecb_europa_eu'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('data_api_ecb_europa_eu'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('data_api_ecb_europa_eu'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('data_api_ecb_europa_eu'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
