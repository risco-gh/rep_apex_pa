prompt --application/shared_components/web_sources/precioestfecha_1
begin
--   Manifest
--     WEB SOURCE: PrecioEstFecha_1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(20822387680455016)
,p_name=>'PrecioEstFecha_1'
,p_static_id=>'precioestfecha_1'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(20818281852455013)
,p_remote_server_id=>wwv_flow_imp.id(18767565471564871)
,p_url_path_prefix=>'/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestres/'
,p_pass_ecid=>true
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(20822566909455017)
,p_web_src_module_id=>wwv_flow_imp.id(20822387680455016)
,p_name=>'ObtenerPrecio'
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
