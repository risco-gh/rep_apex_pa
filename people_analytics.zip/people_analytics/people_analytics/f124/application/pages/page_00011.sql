prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Brecha Salarial_ORIG'
,p_alias=>'BRECHA-SALARIAL-ORIG'
,p_step_title=>'Brecha Salarial_ORIG'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240326074540'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30303066588227421)
,p_plug_name=>'Brecha salarial'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16515266015283155)
,p_region_id=>wwv_flow_imp.id(30303066588227421)
,p_chart_type=>'combo'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16516956270283156)
,p_chart_id=>wwv_flow_imp.id(16515266015283155)
,p_seq=>10
,p_name=>'Brecha salarial mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2) from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes'))
,p_series_type=>'area'
,p_items_value_column_name=>'ROUND(GN_M/GN_F,2)'
,p_items_label_column_name=>'MES'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16516391482283155)
,p_chart_id=>wwv_flow_imp.id(16515266015283155)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16515777048283155)
,p_chart_id=>wwv_flow_imp.id(16515266015283155)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30767768891811424)
,p_plug_name=>'Brecha salarial anual'
,p_parent_plug_id=>wwv_flow_imp.id(30303066588227421)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''label'' as label, round(gn_m/gn_f, 2), null as pct from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, sum(salario) salario from salarios group by codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_landmark_type=>'exclude_landmark'
,p_attribute_02=>'ROUND(GN_M/GN_F,2)'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30526646871430232)
,p_plug_name=>'Salario mensual masculino'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16487382655283126)
,p_region_id=>wwv_flow_imp.id(30526646871430232)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16488987923283130)
,p_chart_id=>wwv_flow_imp.id(16487382655283126)
,p_seq=>10
,p_name=>'Salario mensual masculino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios',
'  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''M'' and dato_valido = ''S'')',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_group_short_desc_column_name=>'MES'
,p_items_label_column_name=>'MES'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16487783019283127)
,p_chart_id=>wwv_flow_imp.id(16487382655283126)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16488344035283129)
,p_chart_id=>wwv_flow_imp.id(16487382655283126)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30767926169811425)
,p_plug_name=>'Salario masculino anual'
,p_parent_plug_id=>wwv_flow_imp.id(30526646871430232)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Salario M'' as label, round(avg(salario_e)/12, 0) as value, null as pct from(',
' select t_sal.codigo_empleado, sum(salario) salario_e from salarios',
'   t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''M'' and to_char(mm_yyyy, ''YYYY'') = ''2021''',
'  and dato_valido = ''S'' group by t_sal.codigo_empleado',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30527183545430237)
,p_plug_name=>'Salario mensual femenino'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16490315907283137)
,p_region_id=>wwv_flow_imp.id(30527183545430237)
,p_chart_type=>'area'
,p_height=>'50'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16492010158283138)
,p_chart_id=>wwv_flow_imp.id(16490315907283137)
,p_seq=>10
,p_name=>'Salario mensual femenino'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(avg(salario_e), 0) from(',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, salario salario_e from salarios',
'  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''F'' and dato_valido = ''S'')',
'  group by mes order by mes'))
,p_items_value_column_name=>'ROUND(AVG(SALARIO_E),0)'
,p_items_label_column_name=>'MES'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16490862642283137)
,p_chart_id=>wwv_flow_imp.id(16490315907283137)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16491445129283138)
,p_chart_id=>wwv_flow_imp.id(16490315907283137)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30768039786811426)
,p_plug_name=>'Salario femenino anual'
,p_parent_plug_id=>wwv_flow_imp.id(30527183545430237)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Salario F'' as label, round(avg(salario_e)/12, 0) as value, null as pct from(',
' select t_sal.codigo_empleado, sum(salario) salario_e from salarios',
'   t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''F'' and to_char(mm_yyyy, ''YYYY'') = ''2021''',
'  and dato_valido = ''S'' group by t_sal.codigo_empleado',
' )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30527647676430242)
,p_plug_name=>'Brecha salarial por provincia'
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(16518346005283157)
,p_region_id=>wwv_flow_imp.id(30527647676430242)
,p_height=>154
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'3'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(16518820344283159)
,p_map_region_id=>wwv_flow_imp.id(16518346005283157)
,p_name=>'Brecha por provincia'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t2.provincia, centro, brecha_v, latitud, longitud from (select centro, round(gn_m/gn_f, 2) brecha_v from (',
'select t_emp.genero_mf genero, codigo_centro centro, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, sum(salario) salario from salarios group by codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by codigo_centro, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))) t1',
'join centros t2 on t1.centro = t2.codigo_centro',
'join centros_geo t3 on t2.provincia = t3.provincia'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_stroke_color=>'#0f0274'
,p_fill_color=>'#009dff'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Circle'
,p_point_svg_shape_scale=>'&BRECHA_V.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&PROVINCIA.: &BRECHA_V.<b/>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_CODIGO_CENTRO:&CENTRO.'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30767032668811416)
,p_plug_name=>'Brecha salarial y salario mensual (M/F)'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>80
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16493466665283140)
,p_region_id=>wwv_flow_imp.id(30767032668811416)
,p_chart_type=>'combo'
,p_height=>'100'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16495747052283141)
,p_chart_id=>wwv_flow_imp.id(16493466665283140)
,p_seq=>10
,p_name=>'Salario mensual (M/F)'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t1.label as label, t1.series as series, decode(t1.series, ''F'', t1.value, ''M'', t1.value - t2.value) as value, color, t1.value valor from (',
'select mes as label, round(avg(salario_e), 0) as value,',
' genero_mf as series, decode(genero_mf, ''F'', ''#a274a7'', ''M'', ''#4857a7'') as color',
' from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''F'', ''M'') and dato_valido = ''S''',
')  group by mes, genero_mf) t1',
'join',
'(',
' select mes as label, round(avg(salario_e), 0) as value from (',
' select to_char(mm_yyyy, ''mm'') mes, t_sal.codigo_empleado, genero_mf, salario salario_e from salarios  t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''F'') and dato_valido = ''S''',
') group by mes',
') t2 on (t2.label = t1.label)',
' order by label, value desc'))
,p_series_type=>'area'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'VALOR'
,p_color=>'&COLOR.'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16496339331283141)
,p_chart_id=>wwv_flow_imp.id(16493466665283140)
,p_seq=>20
,p_name=>'Brecha salarial'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2) value, round(gn_m/gn_f, 2)*1000 valor from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes'))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MES'
,p_items_short_desc_column_name=>'VALUE'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'on'
,p_items_label_rendered=>true
,p_items_label_position=>'belowMarker'
,p_items_label_font_family=>'Arial Black'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16493915830283140)
,p_chart_id=>wwv_flow_imp.id(16493466665283140)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16494583178283140)
,p_chart_id=>wwv_flow_imp.id(16493466665283140)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16495129732283141)
,p_chart_id=>wwv_flow_imp.id(16493466665283140)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_font_color=>'#f7b741'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30768702957811433)
,p_plug_name=>'Salario mensual (F/M) por trimestre'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>90
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16504910930283148)
,p_region_id=>wwv_flow_imp.id(30768702957811433)
,p_chart_type=>'boxPlot'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16507250225283149)
,p_chart_id=>wwv_flow_imp.id(16504910930283148)
,p_seq=>10
,p_name=>'Salario F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = ''2021'') t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where',
'   dato_valido = ''S'' and genero_mf = ''F''',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado'))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#a274a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_GENERO_MF:F'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16506690427283149)
,p_chart_id=>wwv_flow_imp.id(16504910930283148)
,p_seq=>20
,p_name=>'Salario M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select quarter, empleado, round(avg(salario), 2) salario from (',
' select t_sal.quarter quarter, t_sal.codigo_empleado empleado, t_sal.salario from',
'   (select case',
'    when to_number(to_char(mm_yyyy, ''mm'')) < 4 then ''q1''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 3 and to_number(to_char(mm_yyyy, ''mm'')) < 7 then ''q2''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 6 and to_number(to_char(mm_yyyy, ''mm'')) < 10 then ''q3''',
'    when to_number(to_char(mm_yyyy, ''mm'')) > 9 then ''q4''',
'    end',
'     quarter, mm_yyyy mes, codigo_empleado, salario from salarios where to_char(mm_yyyy, ''YYYY'') = ''2021'') t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where',
'   dato_valido = ''S'' and genero_mf = ''M''',
'order by quarter, t_sal.codigo_empleado)',
'group by quarter, empleado'))
,p_series_type=>'boxPlot'
,p_items_value_column_name=>'SALARIO'
,p_items_label_column_name=>'QUARTER'
,p_color=>'#4857a7'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16505443892283148)
,p_chart_id=>wwv_flow_imp.id(16504910930283148)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16506041273283148)
,p_chart_id=>wwv_flow_imp.id(16504910930283148)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30770470042811451)
,p_plug_name=>'Salario por rango de edad'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30769274609811439)
,p_plug_name=>'Brecha salarial por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(30770470042811451)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16501633701283146)
,p_region_id=>wwv_flow_imp.id(30769274609811439)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16503397476283146)
,p_chart_id=>wwv_flow_imp.id(16501633701283146)
,p_seq=>10
,p_name=>'Brecha por rango edad'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rango_e label, round(gn_m/gn_f, 2) value from (',
'select t_emp.genero_mf genero, t_emp.rangos_edad rango_e,',
' round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by t_emp.rangos_edad, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f)) order by rango_e'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16503949075283147)
,p_chart_id=>wwv_flow_imp.id(16501633701283146)
,p_seq=>20
,p_name=>'Brecha avg'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct rangos_edad label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16502155761283146)
,p_chart_id=>wwv_flow_imp.id(16501633701283146)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16502707985283146)
,p_chart_id=>wwv_flow_imp.id(16501633701283146)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30770627474811452)
,p_plug_name=>'Salario M/F por rango de edad'
,p_parent_plug_id=>wwv_flow_imp.id(30770470042811451)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16497717156283143)
,p_region_id=>wwv_flow_imp.id(30770627474811452)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16500687909283145)
,p_chart_id=>wwv_flow_imp.id(16497717156283143)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''F'' and dato_valido = ''S''',
'  group by t_emp.rangos_edad order by rangos_edad'))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_RANGOS_EDAD,P6_GENERO_MF:&RANGO_E.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16500004690283144)
,p_chart_id=>wwv_flow_imp.id(16497717156283143)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.rangos_edad rango_e, round(avg(salario), 2) salario_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf = ''M'' and dato_valido = ''S''',
'  group by t_emp.rangos_edad order by rangos_edad'))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'RANGO_E'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_RANGOS_EDAD,P6_GENERO_MF:&RANGO_E.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16498290812283143)
,p_chart_id=>wwv_flow_imp.id(16497717156283143)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16498823780283143)
,p_chart_id=>wwv_flow_imp.id(16497717156283143)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16499480803283143)
,p_chart_id=>wwv_flow_imp.id(16497717156283143)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31260249254440611)
,p_plug_name=>unistr('Salario por categor\00EDa profesional')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31260424000440612)
,p_plug_name=>unistr('Brecha salarial por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(31260249254440611)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16508622325283150)
,p_region_id=>wwv_flow_imp.id(31260424000440612)
,p_chart_type=>'combo'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16510374999283151)
,p_chart_id=>wwv_flow_imp.id(16508622325283150)
,p_seq=>10
,p_name=>unistr('Brecha por categor\00EDa')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select categ, round(gn_m/gn_f, 2) from (',
'select t_emp.genero_mf genero, t_emp.categ_profesional categ, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by t_emp.categ_profesional, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f)) order by categ'))
,p_series_type=>'bar'
,p_items_value_column_name=>'ROUND(GN_M/GN_F,2)'
,p_items_label_column_name=>'CATEG'
,p_color=>'#f7b741'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_css_classes=>'font-size:14px;color:black;'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16510970336283152)
,p_chart_id=>wwv_flow_imp.id(16508622325283150)
,p_seq=>20
,p_name=>'Brecha avg'
,p_data_source_type=>'SQL'
,p_data_source=>'select distinct categ_profesional label, 1 value from empleados'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16509157183283151)
,p_chart_id=>wwv_flow_imp.id(16508622325283150)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16509720480283151)
,p_chart_id=>wwv_flow_imp.id(16508622325283150)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31260453736440613)
,p_plug_name=>unistr('Salario M/F por categor\00EDa profesional')
,p_parent_plug_id=>wwv_flow_imp.id(31260249254440611)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16511911878283153)
,p_region_id=>wwv_flow_imp.id(31260453736440613)
,p_chart_type=>'bar'
,p_height=>'150'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16513631527283153)
,p_chart_id=>wwv_flow_imp.id(16511911878283153)
,p_seq=>10
,p_name=>'Salario_F'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''F'' genero from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf  = ''F'' and dato_valido = ''S''',
'  group by t_emp.categ_profesional'))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#a274a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_CATEG_PROFESIONAL,P6_GENERO_MF:&CATEG.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16514260606283154)
,p_chart_id=>wwv_flow_imp.id(16511911878283153)
,p_seq=>20
,p_name=>'Salario_M'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t_emp.categ_profesional categ, round(avg(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e, ''M'' genero from',
' (select codigo_empleado, salario from salarios) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf  = ''M'' and dato_valido = ''S''',
'  group by t_emp.categ_profesional'))
,p_items_value_column_name=>'SALARIO_E'
,p_items_label_column_name=>'CATEG'
,p_color=>'#4857a7'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_CATEG_PROFESIONAL,P6_GENERO_MF:&CATEG.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16512448258283153)
,p_chart_id=>wwv_flow_imp.id(16511911878283153)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16513057348283153)
,p_chart_id=>wwv_flow_imp.id(16511911878283153)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
