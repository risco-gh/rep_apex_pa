prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(13461970027287120)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13761329592287666)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_text_01=>unistr('\00CDndice y descripci\00F3n de contenido')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13803929255908737)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Resumen'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>unistr('Cuadro resumen de todos los indicadores: brecha salarial, \00EDndice de concentraci\00F3n, absentismo, diversidad funcional, \00EDndice de distribuci\00F3n, retenci\00F3n de talento y rotaci\00F3n voluntaria.')
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16964427701763744)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Brecha salarial'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Brecha salarial por g\00E9nero. <br>'),
unistr('Evoluci\00F3n temporal de la brecha y de los salarios por g\00E9nero.<br>'),
unistr('Distribuci\00F3n de brecha salarial por provincia, rango de edad y categor\00EDa laboral.')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15634594916255806)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Absentismo'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Ratio de absentismo con respecto a los d\00EDas laborables. <br>'),
unistr('Total de d\00EDas de absentismo en el a\00F1o. Evoluci\00F3n temporal del absentismo.<br>'),
unistr('Distribuci\00F3n de absentismo por centro de trabajo, tipo de absentismo, categor\00EDa laboral y g\00E9nero.')))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14804723111925977)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Informe Empleados'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Listado de todos los empleados con la capacidad de filtrar los datos en base a determinadas caracter\00EDsticas como tipo de contrato, rango de edad, categor\00EDa profesional, puesto de trabajo, g\00E9nero, centro o puesto clave.<br> '),
unistr('Accesible directamente desde el men\00FA o navegando desde los gr\00E1ficos del panel de brecha salarial.')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16613746636374271)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Informe Absentismo'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Listado de todas las ausencias con la capacidad de filtrar los datos por tipo de absentismo, rango de edad, categor\00EDa profesional, g\00E9nero, comunidad aut\00F3noma y centro de trabajo.'),
'<br> ',
unistr('Accesible directamente desde el men\00FA o navegando desde los gr\00E1ficos del panel de absentismo.')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16658980798901585)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Informe Salarios'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-chart'
,p_list_text_01=>unistr('Listado de los salarios con la capacidad de filtrar los datos, totalizarlos y destacar los que cumplen alg\00FAn criterio.')
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19127267799884177)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Datos auxiliares'
,p_list_text_04=>'my_card'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19129559422993839)
,p_list_item_display_sequence=>81
,p_list_item_link_text=>'Precios carburantes volcados'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:19:::'
,p_parent_list_item_id=>wwv_flow_imp.id(19127267799884177)
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19132710128170766)
,p_list_item_display_sequence=>82
,p_list_item_link_text=>'Precios carburantes tiempo real'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:::'
,p_parent_list_item_id=>wwv_flow_imp.id(19127267799884177)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19153344538440595)
,p_list_item_display_sequence=>83
,p_list_item_link_text=>'Mapas de gasolineras'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_parent_list_item_id=>wwv_flow_imp.id(19127267799884177)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
