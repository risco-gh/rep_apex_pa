prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>'WS Precios Carburantes JSON'
,p_alias=>'WS-PRECIOS-CARBURANTES-JSON'
,p_step_title=>'WS Precios Carburantes JSON'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.no_break {',
'  white-space: nowrap;',
'}',
'',
''))
,p_step_template=>wwv_flow_imp.id(13465178960287177)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240517155005'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(20372246445407444)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH test_data (json) AS',
'(',
unistr('---- 1   SELECT ''{"ListaEESSPrecio":[{"C.P.":"02250","Direcci\00F3n":"AVENIDA CASTILLA LA MANCHA, 26","Horario":"L-D: 07:00-22:00","Latitud":"39,211417","Localidad":"ABENGIBRE","Longitud (WGS84)":"-1,539167","Margen":"D","Municipio":"Abengibre","Precio B')
||unistr('iodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,379","Precio Gasoleo B":"1,059","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"')
||unistr('","Precio Gasolina 95 E5":"1,569","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"N\00BA 10.935","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ste')
||unistr('r met\00EDlico":"0,0","IDEESS":"4375","IDMunicipio":"52","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02152","Direcci\00F3n":"CR CM-332, 46,4","Horario":"L-D: 7:00-23:00","Latitud":"39,100389","Localidad":"ALATOZ","Longitud (WGS84)":"-1,346083","Margen":"I","M')
||unistr('unicipio":"Alatoz","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,689","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,729')
||unistr('","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,739","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"REPSOL","Tipo Venta":"P","%')
||unistr(' BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"5122","IDMunicipio":"53","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"CALLE FEDERICO GARCIA LORCA, 1","Horario":"L-D: 24H","Latitud":"39,000861","Localidad":"ALBACETE","Longitud (')
||unistr('WGS84)":"-1,849833","Margen":"D","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,389","Precio Gasoleo ')
||unistr('B":"","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,519","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tu')
||unistr('lo":"PLENOIL","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"13933","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"AVENIDA 1\00BA DE MAYO, S\005C/N","Horario":"L-S: 08:00-22:00; D: 09:00-21:00","Lat')
||'itud":"38,985667","Localidad":"ALBACETE","Longitud (WGS84)":"-1,868500","Margen":"N","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr'
||unistr('\00F3leo":"","Precio Gasoleo A":"1,529","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,589","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,679","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"1,799","Pre')
||unistr('cio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"CARREFOUR","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"10765","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"}]}'' FROM DUAL'),
'---- 2',
unistr('   SELECT ''[{"C.P.":"02250","Direcci\00F3n":"AVENIDA CASTILLA LA MANCHA, 26","Horario":"L-D: 07:00-22:00","Latitud":"39,211417","Localidad":"ABENGIBRE","Longitud (WGS84)":"-1,539167","Margen":"D","Municipio":"Abengibre","Precio Biodiesel":"","Precio Bioe')
||unistr('tanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,379","Precio Gasoleo B":"1,059","Precio Gasoleo Premium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5"')
||unistr(':"1,569","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"N\00BA 10.935","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS')
||unistr('":"4375","IDMunicipio":"52","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02152","Direcci\00F3n":"CR CM-332, 46,4","Horario":"L-D: 7:00-23:00","Latitud":"39,100389","Localidad":"ALATOZ","Longitud (WGS84)":"-1,346083","Margen":"I","Municipio":"Alatoz","Preci')
||unistr('o Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,689","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,729","Precio Gasolina 95 E10')
||unistr('":"","Precio Gasolina 95 E5":"1,739","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"REPSOL","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ste')
||unistr('r met\00EDlico":"0,0","IDEESS":"5122","IDMunicipio":"53","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"CALLE FEDERICO GARCIA LORCA, 1","Horario":"L-D: 24H","Latitud":"39,000861","Localidad":"ALBACETE","Longitud (WGS84)":"-1,849833","Marg')
||unistr('en":"D","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo A":"1,389","Precio Gasoleo B":"","Precio Gasoleo Pre')
||unistr('mium":"","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,519","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"","Precio Hidrogeno":"","Provincia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"PLENOIL","Tipo Venta')
||unistr('":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"13933","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"},{"C.P.":"02001","Direcci\00F3n":"AVENIDA 1\00BA DE MAYO, S\005C/N","Horario":"L-S: 08:00-22:00; D: 09:00-21:00","Latitud":"38,985667","Locali')
||unistr('dad":"ALBACETE","Longitud (WGS84)":"-1,868500","Margen":"N","Municipio":"Albacete","Precio Biodiesel":"","Precio Bioetanol":"","Precio Gas Natural Comprimido":"","Precio Gas Natural Licuado":"","Precio Gases licuados del petr\00F3leo":"","Precio Gasoleo ')
||'A":"1,529","Precio Gasoleo B":"","Precio Gasoleo Premium":"1,589","Precio Gasolina 95 E10":"","Precio Gasolina 95 E5":"1,679","Precio Gasolina 95 E5 Premium":"","Precio Gasolina 98 E10":"","Precio Gasolina 98 E5":"1,799","Precio Hidrogeno":"","Provin'
||unistr('cia":"ALBACETE","Remisi\00F3n":"dm","R\00F3tulo":"CARREFOUR","Tipo Venta":"P","% BioEtanol":"0,0","% \00C9ster met\00EDlico":"0,0","IDEESS":"10765","IDMunicipio":"54","IDProvincia":"02","IDCCAA":"07"}]'' FROM DUAL'),
'--select :DATA_LIST from dual',
')',
'SELECT COD_POS, DIRECC',
'FROM test_data td,',
'JSON_TABLE(td.json, ',
'           ''$[*]'' ',
'           COLUMNS (row_number FOR ORDINALITY, ',
'                    COD_POS VARCHAR2 PATH ''$."C.P."'', ',
unistr('                    DIRECC VARCHAR2 PATH ''$."Direcci\00F3n"''))')))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20372340793407445)
,p_query_column_id=>1
,p_column_alias=>'COD_POS'
,p_column_display_sequence=>10
,p_column_heading=>'Cod Pos'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20372426319407446)
,p_query_column_id=>2
,p_column_alias=>'DIRECC'
,p_column_display_sequence=>20
,p_column_heading=>'Direcc'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39124962864081795)
,p_name=>'Search Results'
,p_template=>wwv_flow_imp.id(13556604986287250)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(20822387680455016)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(13602944078287284)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>100000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20369106414407413)
,p_query_column_id=>1
,p_column_alias=>'FECHA'
,p_column_display_sequence=>10
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20776698256941820)
,p_query_column_id=>2
,p_column_alias=>'DATA_LIST'
,p_column_display_sequence=>20
,p_column_heading=>'Data List'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39127378729081801)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13521013963287234)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20361857125401009)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39127378729081801)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(13638064657287332)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&APP_SESSION.::&DEBUG.:RR,31::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39093617326809055)
,p_name=>'P28_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39127378729081801)
,p_item_display_point=>'NEXT'
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('<b>\00DAltima actualizaci\00F3n</b>')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'to_char(sysdate, ''dd/mm/yyyy hh24:mi:ss'')||'' UTC''',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
