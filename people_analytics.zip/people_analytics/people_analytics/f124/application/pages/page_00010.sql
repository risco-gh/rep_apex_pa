prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Absentismo_ORIG'
,p_alias=>'ABSENTISMO-ORIG'
,p_step_title=>'Absentismo_ORIG'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'require(["ojs/ojtagcloud"] ,function() {});'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240401142216'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31774266827183116)
,p_plug_name=>'Absentismo (%)'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>2
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16747017843502746)
,p_region_id=>wwv_flow_imp.id(31774266827183116)
,p_chart_type=>'dial'
,p_title=>'Pct absentismo'
,p_width=>'90'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'percent'
,p_value_format_scaling=>'auto'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>false
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16747524389502746)
,p_chart_id=>wwv_flow_imp.id(16747017843502746)
,p_seq=>10
,p_name=>'Pct absentismo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'label, tot_dias, val_dias,',
'case',
' when value <= 5 then ''#76b417''',
' when value > 5 and value <= 20 then ''#fbb03b''',
' when value > 20 then ''#e10000''',
' end a_color, pct',
' from (',
'select ''Absentismo total'' label,',
'round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100value, (215/12)*tot_emp*n_meses tot_dias, dias_abs val_dias,',
'round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 nval,',
' null pct from (',
'select count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO ABST ',
'     join EMPLEADOS EMPS on (EMPS.codigo_empleado = ABST.codigo_empleado)',
'     where to_char(ABST.MES, ''YYYY'') = ''2021'' and EMPS.dato_valido = ''S''     ',
'     group by ABST.mes order by ABST.mes',
')',
't1) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by dias_abs, n_meses))'))
,p_items_value_column_name=>'VAL_DIAS'
,p_items_max_value=>'TOT_DIAS'
,p_color=>'&A_COLOR.'
,p_items_label_rendered=>false
,p_gauge_plot_area_color=>'&A_COLOR.'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31775227318183126)
,p_plug_name=>unistr('Total d\00EDas')
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16745564257502744)
,p_region_id=>wwv_flow_imp.id(31775227318183126)
,p_chart_type=>'dial'
,p_width=>'90'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'number'
,p_value_format_scaling=>'auto'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>false
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16746018466502744)
,p_chart_id=>wwv_flow_imp.id(16745564257502744)
,p_seq=>10
,p_name=>'Ausencia total'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, dias_m, case',
' when dias_m <= 500 then ''#76b417''',
' when dias_m > 500 and dias_m <= 1000 then ''#fbb03b''',
' when dias_m > 1000 then ''#e10000''',
' end a_color from (',
unistr('select ''D\00EDas totales'' label, round(sum(nvl(n_dias, 0)),0) dias_m from ABSENTISMO ABST'),
' join EMPLEADOS EMPS on (EMPS.codigo_empleado = ABST.codigo_empleado)',
' where to_char(ABST.MES, ''YYYY'') = ''2021'' and EMPS.dato_valido = ''S'')'))
,p_items_value_column_name=>'DIAS_M'
,p_items_max_value=>'DIAS_M'
,p_color=>'&A_COLOR.'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31775407736183127)
,p_plug_name=>'Absentismo por mes en 2021'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16748571616502747)
,p_region_id=>wwv_flow_imp.id(31775407736183127)
,p_chart_type=>'line'
,p_height=>'120'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16750279011502748)
,p_chart_id=>wwv_flow_imp.id(16748571616502747)
,p_seq=>10
,p_name=>'Absentismo mensual'
,p_data_source_type=>'SQL'
,p_data_source=>'select to_char(mes, ''Mon'') label, to_char(mes, ''Mon'') mes_c, round(sum(nvl(n_dias, 0)), 2) dias_m from ABSENTISMO where to_char(MES, ''YYYY'') = ''2021'' group by mes order by mes'
,p_items_value_column_name=>'DIAS_M'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'DIAS_M'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16749090216502747)
,p_chart_id=>wwv_flow_imp.id(16748571616502747)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'none'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16749666656502748)
,p_chart_id=>wwv_flow_imp.id(16748571616502747)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>unistr('N\00BA D\00EDas')
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32380860076351292)
,p_plug_name=>'Dummy2'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32380755843351291)
,p_plug_name=>unistr('N\00BA d\00EDas por tipo de absentismo')
,p_parent_plug_id=>wwv_flow_imp.id(32380860076351292)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'',
'lv_cloud_tag_items clob;',
'lv_legend_items clob;',
'lv_chart_output clob;',
'lv_ndias_band clob;',
'',
'',
'Begin ',
'',
'-- Prepare JSON for Tag Cloud Items',
'',
'select JSON_ARRAYAGG',
'(',
'JSON_OBJECT',
'	(',
'--	KEY ''id'' VALUE TO_CHAR(EMPNO),',
'	KEY ''label'' VALUE TIPO_ABSENTISMO,',
'	KEY ''value'' VALUE N_DIAS,',
'	KEY ''categories'' VALUE ',
'		case',
'			when N_DIAS between 0 and 50 then JSON_ARRAY(''0-50'')',
'			when N_DIAS between 51 and 100 then JSON_ARRAY(''51-100'')',
'			when N_DIAS between 101 and 150 then JSON_ARRAY(''101-150'')',
'			when N_DIAS > 150 then JSON_ARRAY(''Above 150'') ',
'		end,',
'	KEY ''color'' VALUE C_ABS,',
'	KEY ''shortDesc'' VALUE ''MOTIVO - '' || TIPO_ABSENTISMO || '': ABSENTISMO - '' || N_DIAS',
'    )',
'    FORMAT JSON ORDER BY TIPO_ABSENTISMO RETURNING CLOB',
') into lv_cloud_tag_items',
'from (select c_abs as C_ABS, t_abs as TIPO_ABSENTISMO, sum(n_dias) N_DIAS from (',
'select',
'      case',
'           when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%'' then ''#046a13''',
unistr('           when tipo_absentismo like ''%Viernes de libre disposici\00F3n%'' then ''#f9e904'''),
'           when tipo_absentismo like ''%Fallecimiento conyuge, hijos padres o hermanos%'' then ''#fdc7c7''',
unistr('           when tipo_absentismo like ''%Ausencia M\00E9dica%'' then ''#193591'''),
'           when tipo_absentismo like ''%Operacion resto familiares%'' then ''#2E86C1''',
'           when tipo_absentismo like ''%Mudanza%'' then ''#7D3C98''',
'           when tipo_absentismo like ''%Baja IT larga duracion%'' then ''#a40a40''',
'           when tipo_absentismo like ''%Baja IT COVID%'' then ''#F39C12''',
'           when tipo_absentismo like ''%Matrimonio%'' then ''#fb9745''',
unistr('           when tipo_absentismo like ''%Operaci\00F3n conyuge, hijos, padres y hermanos%'' then ''#333c4e'''),
unistr('           when tipo_absentismo like ''%Baja IT corta duraci\00F3n%'' then ''#0897df'''),
'           when tipo_absentismo like ''%Lactancia acumulada%'' then ''#E74C3C''',
'      end c_abs,',
'      case when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%''',
'           then ''Maternidad/Paternidad''',
'           else tipo_absentismo',
'      end t_abs,',
'      n_dias',
'from absentismo where to_char(mes, ''yyyy'') = ''2021'') group by c_abs, t_abs);',
'',
'',
'select  LISTAGG( distinct ',
'	case',
'		when N_DIAS between 0 and 50 then ''0-50'' ',
'		when N_DIAS between 51 and 100 then ''51-100'' ',
'		when N_DIAS between 101 and 150 then ''101-150'' ',
'		when N_DIAS > 150 then ''Above 150''',
'	end,'','' ) NDIAS_BAND ',
'into lv_ndias_band',
'from (select t_abs TIPO_ABSENTISMO, sum(n_dias) N_DIAS from (',
'select case when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%'' then ''Maternidad/Paternidad'' else tipo_absentismo end t_abs, n_dias',
'from absentismo) group by t_abs);',
'',
'-- Prepare JSON for Legend Items based on Unique List',
'',
'select JSON_ARRAYAGG(',
'                        JSON_OBJECT (',
'						KEY ''items'' VALUE (JSON_ARRAY (JSON_OBJECT(',
'						KEY ''text'' VALUE COLUMN_VALUE,',
'						KEY ''color'' VALUE',
'							case',
'								when COLUMN_VALUE = ''0-50'' then ''#2E86C1''',
'								when COLUMN_VALUE = ''51-100'' then ''#7D3C98''',
'								when COLUMN_VALUE = ''101-150''  then ''#F39C12''',
'								when COLUMN_VALUE = ''Above 150'' then ''#E74C3C''',
'							end',
'                                    ))))',
'                    ) into lv_legend_items',
'from apex_string.split(lv_ndias_band,'','');',
'',
'-- Generate Chart for Tag Cloud and Pass the JSON',
'',
'lv_chart_output := ''<oj-tag-cloud',
'            id = "TAG_CLOUD1"',
'            layout ="cloud"',
'            selection-mode = "single"',
'            animation-on-display="auto"',
'            animation-on-data-change="auto"',
'            items="'' || apex_escape.html(lv_cloud_tag_items) || ''">',
'            </oj-tag-cloud>'';',
'',
'-- Generate Legend and Pass the JSON',
'',
'lv_chart_output := lv_chart_output ||  ''<oj-legend ',
'            id = "LEGEND1" ',
'            text-style = {"fontSize":"15px","fontWeight":700} ',
'            symbol-height = 10 ',
'            class = "legend-size" ',
'            hide-and-show-behavior="off" halign="center"',
'            orientation="horizontal" ',
'            sections="''||apex_escape.html(lv_legend_items) || ''">',
'            </oj-legend>'';',
'',
'',
'return lv_chart_output;',
'',
'End;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32989354961776915)
,p_plug_name=>'Dummy3'
,p_parent_plug_id=>wwv_flow_imp.id(32380860076351292)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32379914643351282)
,p_plug_name=>'Absentismo por comunidad'
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(16744075787502741)
,p_region_id=>wwv_flow_imp.id(32379914643351282)
,p_height=>160
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(16744571830502742)
,p_map_region_id=>wwv_flow_imp.id(16744075787502741)
,p_name=>'Absentismo'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
't2.comunidad, round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 n_dias,',
'to_char(round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100)||''%'' pc_dias',
', geometry',
'from (',
'select codigo_centro, count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_centro, codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select codigo_centro, sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select codigo_centro, mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021'' group by codigo_centro, mes order by mes',
')',
't1',
' group by codigo_centro) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by codigo_centro, dias_abs, n_meses) t3',
'join centros t2 on t2.codigo_centro = t3.codigo_centro',
'join map_comunidades t4 on t4.name = t2.comunidad'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'TealGrn'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'N_DIAS'
,p_fill_opacity=>.5
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&COMUNIDAD.: &PC_DIAS.</b>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_COMUNIDAD:&COMUNIDAD.'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32380283575351286)
,p_plug_name=>unistr('Distribuci\00F3n por categor\00EDa laboral')
,p_region_name=>'fancy'
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-right-lg'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empl.categ_profesional, round(sum(n_dias)*100/ntot, 0) value,',
'      case',
'           when categ_profesional like ''%COMERCIAL%'' then ''#a40a40''',
'           when categ_profesional like ''%DESARROLLO%'' then ''#046a13''',
'           when categ_profesional like ''%SOPORTE%'' then ''#fb9745''',
'           when categ_profesional like ''%TECNICO%'' then ''#fdc7c7''',
'      end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' group by empl.categ_profesional, ntot order by sum(n_dias) desc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16741034653502738)
,p_region_id=>wwv_flow_imp.id(32380283575351286)
,p_chart_type=>'pie'
,p_height=>'160'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_show_gauge_value=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'    options.dataFilter = function( data ) {',
'        data.series[0].pieSliceExplode = 1;',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16741593950502739)
,p_chart_id=>wwv_flow_imp.id(16741034653502738)
,p_seq=>10
,p_name=>unistr('Absentismo por categor\00EDa')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'CATEG_PROFESIONAL'
,p_color=>'&SERIES_COLORS.'
,p_items_label_rendered=>true
,p_items_label_position=>'start'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32383550859351319)
,p_plug_name=>unistr('Distribuci\00F3n por tipo de absentismo')
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-lg'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tipo_absentismo, round(sum(n_dias)*100/ntot, 0) value, ntot,',
'      case',
'           when tipo_absentismo like ''%Maternidad%'' or tipo_absentismo like ''%Paternidad%'' then ''#046a13''',
unistr('           when tipo_absentismo like ''%Viernes de libre disposici\00F3n%'' then ''#f9e904'''),
'           when tipo_absentismo like ''%Fallecimiento conyuge, hijos padres o hermanos%'' then ''#fdc7c7''',
unistr('           when tipo_absentismo like ''%Ausencia M\00E9dica%'' then ''#193591'''),
'           when tipo_absentismo like ''%Operacion resto familiares%'' then ''#2E86C1''',
'           when tipo_absentismo like ''%Mudanza%'' then ''#7D3C98''',
'           when tipo_absentismo like ''%Baja IT larga duracion%'' then ''#a40a40''',
'           when tipo_absentismo like ''%Baja IT COVID%'' then ''#F39C12''',
'           when tipo_absentismo like ''%Matrimonio%'' then ''#fb9745''',
unistr('           when tipo_absentismo like ''%Operaci\00F3n conyuge, hijos, padres y hermanos%'' then ''#333c4e'''),
unistr('           when tipo_absentismo like ''%Baja IT corta duraci\00F3n%'' then ''#0897df'''),
'           when tipo_absentismo like ''%Lactancia acumulada%'' then ''#E74C3C''',
'      end series_colors',
' from absentismo abs_1',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' group by abs_1.tipo_absentismo, ntot order by sum(n_dias) desc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16742585338502739)
,p_region_id=>wwv_flow_imp.id(32383550859351319)
,p_chart_type=>'donut'
,p_height=>'160'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16743021792502740)
,p_chart_id=>wwv_flow_imp.id(16742585338502739)
,p_seq=>10
,p_name=>'Absentismo por motivo'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'TIPO_ABSENTISMO'
,p_color=>'&SERIES_COLORS.'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32986410387776885)
,p_plug_name=>unistr('Por g\00E9nero y edad')
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empl.rangos_edad, empl.genero_mf, round(sum(n_dias)*100/ntot, 0) value, to_char(round(sum(n_dias)*100/ntot, 0))||''%'' v_lab,',
'case',
'    when empl.rangos_edad like ''%26-35%'' then 0',
'    when empl.rangos_edad like ''36-45'' then 1',
'    when empl.rangos_edad like ''46-55'' then 2',
'    when empl.rangos_edad like ''> 55'' then 3',
'end n_rango,',
'case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' join (select sum(n_dias) ntot from absentismo abs_2 where to_char(abs_2.mes, ''yyyy'') = ''2021'') on (1 = 1)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.dato_valido = ''S'' group by empl.rangos_edad, empl.genero_mf, ntot order by n_rango',
''))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16733022454502721)
,p_region_id=>wwv_flow_imp.id(32986410387776885)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16734685552502732)
,p_chart_id=>wwv_flow_imp.id(16733022454502721)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y edad')
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'GENERO_MF'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'RANGOS_EDAD'
,p_items_short_desc_column_name=>'V_LAB'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_GENERO_MF,P7_RANGOS_EDAD:&GENERO_MF.,&RANGOS_EDAD.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16733501843502728)
,p_chart_id=>wwv_flow_imp.id(16733022454502721)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'percent'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16734093819502729)
,p_chart_id=>wwv_flow_imp.id(16733022454502721)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32986841165776890)
,p_plug_name=>unistr('Por g\00E9nero y categor\00EDa laboral')
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, genero, round(num_g*100/sum(num_g) over(partition by label)) value, series_colors from (',
' select  empl.categ_profesional label, empl.genero_mf genero, count(*) num_g,',
' case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.genero_mf in (''M'', ''F'') group by empl.categ_profesional, empl.genero_mf',
' order by label',
' )',
''))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16735674992502734)
,p_region_id=>wwv_flow_imp.id(32986841165776890)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16737375485502735)
,p_chart_id=>wwv_flow_imp.id(16735674992502734)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y categor\00EDa profesional')
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'GENERO'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_CATEG_PROFESIONAL,P7_GENERO_MF:&LABEL.,&GENERO.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16736106105502734)
,p_chart_id=>wwv_flow_imp.id(16735674992502734)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16736795872502734)
,p_chart_id=>wwv_flow_imp.id(16735674992502734)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>100
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32987328490776895)
,p_plug_name=>unistr('Por g\00E9nero y tipo de absentismo')
,p_parent_plug_id=>wwv_flow_imp.id(32989354961776915)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, genero, round(num_g*100/sum(num_g) over(partition by label)) value, series_colors from (',
' select  abs_1.tipo_absentismo label, empl.genero_mf genero, count(*) num_g,',
' case',
'    when empl.genero_mf = ''M'' then ''#4857a7''',
'    when empl.genero_mf = ''F'' then ''#a274a7''',
'end series_colors',
' from absentismo abs_1',
' join empleados empl on (empl.codigo_empleado = abs_1.codigo_empleado)',
' where to_char(abs_1.mes, ''yyyy'') = ''2021'' and empl.genero_mf in (''M'', ''F'') group by abs_1.tipo_absentismo, empl.genero_mf',
' order by label',
' )',
''))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16738347924502736)
,p_region_id=>wwv_flow_imp.id(32987328490776895)
,p_chart_type=>'bar'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16740021794502737)
,p_chart_id=>wwv_flow_imp.id(16738347924502736)
,p_seq=>10
,p_name=>unistr('Por g\00E9nero y tipo absentismo')
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'GENERO'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&SERIES_COLORS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_GENERO_MF,P7_TIPO_ABSENTISMO:&GENERO.,&LABEL.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16738895280502736)
,p_chart_id=>wwv_flow_imp.id(16738347924502736)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16739400305502737)
,p_chart_id=>wwv_flow_imp.id(16738347924502736)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_max=>100
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16751021223502754)
,p_name=>'abs_color_pct'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31774266827183116)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16751537656502755)
,p_event_id=>wwv_flow_imp.id(16751021223502754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-BadgeList-value").each(function()',
'{',
'    if (parseInt($(this).text()) < 10) $(this).css(',
'    {',
'        "background-color": "#76b417"',
'    });',
'    else if (parseInt($(this).text()) > 30) $(this).css(',
'    {',
'        "background-color": "#e10000"',
'    });',
'    else $(this).css(',
'    {',
'        "background-color": "#fbb03b"',
'    });',
'});'))
);
wwv_flow_imp.component_end;
end;
/
