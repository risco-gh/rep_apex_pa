prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Resumen_ORIG'
,p_alias=>'RESUMEN-ORIG'
,p_step_title=>'Resumen_ORIG'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240326101741'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30564155872342365)
,p_plug_name=>unistr('\00CDndice concentraci\00F3n')
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--showIcon:t-Region--scrollBody:margin-bottom-none'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select categ_profesional as series, genero_mf as label, count(*) as value',
'from empleados',
' where genero_mf in (''M'', ''F'')',
' group by categ_profesional, genero_mf',
' order by categ_profesional, genero_mf'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16525724964195252)
,p_region_id=>wwv_flow_imp.id(30564155872342365)
,p_chart_type=>'bar'
,p_height=>'540'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'end'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16527493093195254)
,p_chart_id=>wwv_flow_imp.id(16525724964195252)
,p_seq=>10
,p_name=>unistr('Indice concentraci\00F3n')
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_CATEG_PROFESIONAL,P6_GENERO_MF:&SERIES.,&LABEL.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16526253931195252)
,p_chart_id=>wwv_flow_imp.id(16525724964195252)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16526860381195253)
,p_chart_id=>wwv_flow_imp.id(16525724964195252)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_min=>0
,p_max=>1
,p_format_type=>'percent'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31300331525352770)
,p_plug_name=>'Indices_2'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30562924779342353)
,p_plug_name=>unistr('<p>Retenci\00F3n</br> talento</p>')
,p_parent_plug_id=>wwv_flow_imp.id(31300331525352770)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(e_alta), sum(e_tot), sum(e_alta)/sum(e_tot) from (select',
' decode(fecha_baja, null, 1, 0) e_alta, 1 e_tot',
' from empleados where dato_valido = ''S'')'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'SUM(E_TOT)'
,p_attribute_05=>'0'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30563133629342355)
,p_plug_name=>unistr('<p>Rotaci\00F3n</br> voluntaria</p>')
,p_parent_plug_id=>wwv_flow_imp.id(31300331525352770)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''Indice rotaci\00F3n voluntaria'' label, to_char(round(irv, 4)*100)||''%'' value, null pct from ('),
'select sum(e_baja_v), sum(e_tot), sum(e_baja_v)/sum(e_tot) irv from (select',
' decode(tipo_baja, ''VOLUNTARIA'', 1, 0) e_baja_v, 1 e_tot',
' from empleados where dato_valido = ''S''))'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'1'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31300447173352771)
,p_plug_name=>'Indices_1'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30344870502139597)
,p_plug_name=>unistr('<p>\00CDndice</br>distribuci\00F3n</p>')
,p_parent_plug_id=>wwv_flow_imp.id(31300447173352771)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-left-none:margin-right-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''Indice distribuci\00F3n'' label, round(gn_m/gn_f, 2) value, null pct'),
'from (',
'select * from (',
'select genero, count (num_e) num_e from',
' (select distinct genero_mf genero, codigo_empleado num_e from empleados where',
'  genero_mf in (''M'', ''F'') and fecha_baja is null and',
'  dato_valido = ''S'') t_emp',
'  group by genero',
')',
'pivot (sum(num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'1'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30344935632139598)
,p_plug_name=>'<p>Diversidad</br> funcional</p>'
,p_parent_plug_id=>wwv_flow_imp.id(31300447173352771)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-left-none:margin-right-none'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Diversidad funcional'' label, to_char(round(dc_s/(dc_s+dc_n), 4)*100)||''%'' value, null pct from (',
'select * from (',
'select disc, count (num_e) num_e from',
' (select distinct decode(discapacidad, null, ''N'', ''S'') disc, codigo_empleado num_e from empleados where',
'  fecha_baja is null and',
'  dato_valido = ''S'') t_emp',
'  group by disc',
')',
'pivot (sum(num_e) for disc in (''S'' dc_s, ''N'' dc_n))  )'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'1'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32783091373469483)
,p_plug_name=>'Brecha salarial'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-bottom-md:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30342495644139573)
,p_plug_name=>'Brecha salarial por mes'
,p_parent_plug_id=>wwv_flow_imp.id(32783091373469483)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'exclude_landmark'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16531284730195259)
,p_region_id=>wwv_flow_imp.id(30342495644139573)
,p_chart_type=>'bar'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16532997338195260)
,p_chart_id=>wwv_flow_imp.id(16531284730195259)
,p_seq=>10
,p_name=>'Brecha salarial mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round(gn_m/gn_f, 2) from (',
'select t_emp.genero_mf genero, mes, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select to_char(mm_yyyy, ''mm'') mes, codigo_empleado, sum(salario) salario from salarios group by mm_yyyy, codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by mes, t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))   order by mes'))
,p_items_value_column_name=>'ROUND(GN_M/GN_F,2)'
,p_items_label_column_name=>'MES'
,p_color=>'#f7b741'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16531781346195260)
,p_chart_id=>wwv_flow_imp.id(16531284730195259)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16532369758195260)
,p_chart_id=>wwv_flow_imp.id(16531284730195259)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30564676675342370)
,p_plug_name=>'Brecha salarial total'
,p_parent_plug_id=>wwv_flow_imp.id(32783091373469483)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16533966542195261)
,p_region_id=>wwv_flow_imp.id(30564676675342370)
,p_chart_type=>'dial'
,p_width=>'90'
,p_height=>'120'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'number'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>2
,p_value_format_scaling=>'auto'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>false
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>.5
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16534442843195261)
,p_chart_id=>wwv_flow_imp.id(16533966542195261)
,p_seq=>10
,p_name=>'Brecha salarial total'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Brecha salarial'' label, round(gn_m/gn_f, 2) value, 0 min_value, 3 max_value from (',
'select * from (',
'select t_emp.genero_mf genero, round(sum(salario), 2) salario_e, count(t_emp.codigo_empleado) num_e from',
' (select codigo_empleado, sum(salario) salario from salarios group by codigo_empleado) t_sal',
' join empleados t_emp on (t_sal.codigo_empleado = t_emp.codigo_empleado)',
' where genero_mf in (''M'', ''F'') and dato_valido = ''S''',
'  group by t_emp.genero_mf',
')',
'pivot (sum(salario_e/num_e) for genero in (''M'' gn_m, ''F'' gn_f))  )'))
,p_items_value_column_name=>'VALUE'
,p_items_min_value=>'MIN_VALUE'
,p_items_max_value=>'MAX_VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#000000'
,p_items_label_rendered=>false
,p_threshold_values=>'0.8, 1.5, 3'
,p_threshold_colors=>'green, yellow, red'
,p_threshold_display=>'all'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32783119823469484)
,p_plug_name=>'Absentismo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-bottom-md:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30332928094104022)
,p_plug_name=>'Absentismo por mes'
,p_parent_plug_id=>wwv_flow_imp.id(32783119823469484)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16535882927195263)
,p_region_id=>wwv_flow_imp.id(30332928094104022)
,p_chart_type=>'area'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16537545769195264)
,p_chart_id=>wwv_flow_imp.id(16535882927195263)
,p_seq=>10
,p_name=>'Absentismo por mes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mes, round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100 from (',
'select mes, count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct mes, codigo_empleado cod_emp, dias_abs, n_meses from EMPLEADOS_FECHAS emp_f',
'left join (',
'select mes, sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin',
' from (',
'     select',
'      mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO',
'      where  to_char(MES, ''YYYY'') = ''2021''',
'       group by mes order by mes',
') group by mes',
') on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini ))',
'where dias_abs is not null)',
'group by mes, dias_abs, n_meses',
') order by mes'))
,p_max_row_count=>20
,p_items_value_column_name=>'ROUND((DIAS_ABS*8)/((1720/12)*TOT_EMP*N_MESES),4)*100'
,p_items_label_column_name=>'MES'
,p_color=>'#1c9767'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16536350160195263)
,p_chart_id=>wwv_flow_imp.id(16535882927195263)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16536985697195263)
,p_chart_id=>wwv_flow_imp.id(16535882927195263)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30562893014342352)
,p_plug_name=>'Absentismo total'
,p_region_name=>'absentismoBadge'
,p_parent_plug_id=>wwv_flow_imp.id(32783119823469484)
,p_icon_css_classes=>'fa-link'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noBorder:t-Region--scrollBody:margin-bottom-none:margin-left-md:margin-right-md'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Absentismo total'' label,',
'to_char(round((dias_abs*8)/((1720/12)*tot_emp*n_meses), 4)*100)||''%'' value, null pct from (',
'select count(cod_emp) tot_emp, dias_abs, n_meses from (',
'select distinct codigo_empleado cod_emp, dias_abs, n_meses, fecha_alta, fecha_baja, f_ini, f_fin from EMPLEADOS_FECHAS emp_f',
'left join (',
'select sum(dias_m) dias_abs, count(mes) n_meses, min(mes) f_ini, add_months(max(mes), 1)-1d f_fin from (',
'     select mes, sum(nvl(n_dias, 0)) dias_m from ABSENTISMO where  to_char(MES, ''YYYY'') = ''2021'' group by mes order by mes',
')',
't1) on ((emp_f.FECHA_ALTA <= f_fin) and (emp_f.FECHA_BAJA is null or emp_f.FECHA_BAJA > f_ini )) where dias_abs is not null)',
' group by dias_abs, n_meses)'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'0'
,p_attribute_06=>'B'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16538791075195265)
,p_name=>'link_brecha'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(30564676675342370)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16539270334195270)
,p_event_id=>wwv_flow_imp.id(16538791075195265)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' apex.navigation.redirect("f?p=&APP_ID.:3:&SESSION.");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16539652086195270)
,p_name=>'link_absentismo'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(30562893014342352)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16540186916195271)
,p_event_id=>wwv_flow_imp.id(16539652086195270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' apex.navigation.redirect("f?p=&APP_ID.:4:&SESSION.");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16540591582195271)
,p_name=>'bdg_color'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(30562893014342352)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16541049945195271)
,p_event_id=>wwv_flow_imp.id(16540591582195271)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-BadgeList-value").each(function()',
'{',
'    if (parseInt($(this).text()) < 10) $(this).css(',
'    {',
'        "background-color": "#76b417"',
'    });',
'    else if (parseInt($(this).text()) > 30) $(this).css(',
'    {',
'        "background-color": "#e10000"',
'    });',
'    else $(this).css(',
'    {',
'        "background-color": "#fbb03b"',
'    });',
'});'))
);
wwv_flow_imp.component_end;
end;
/
