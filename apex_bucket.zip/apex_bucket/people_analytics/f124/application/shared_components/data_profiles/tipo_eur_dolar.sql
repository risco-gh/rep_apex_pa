prompt --application/shared_components/data_profiles/tipo_eur_dolar
begin
--   Manifest
--     DATA PROFILE: Tipo_EUR_DOLAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(18623167011163519)
,p_name=>'Tipo_EUR_DOLAR'
,p_format=>'JSON'
,p_has_header_row=>false
,p_row_selector=>'dataSets'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(18623973529163525)
,p_data_profile_id=>wwv_flow_imp.id(18623167011163519)
,p_name=>'action'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>20
,p_format_mask=>'YYYY-MM-DD"T"HH24:MI:SS'
,p_has_time_zone=>false
,p_selector=>'action'
,p_remote_attribute_name=>'attributes'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(18658871981914416)
,p_data_profile_id=>wwv_flow_imp.id(18623167011163519)
,p_name=>'series'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'DOCUMENT_FRAGMENT'
,p_has_time_zone=>true
,p_selector=>'series'
);
wwv_flow_imp.component_end;
end;
/
