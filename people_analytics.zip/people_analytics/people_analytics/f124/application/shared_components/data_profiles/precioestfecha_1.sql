prompt --application/shared_components/data_profiles/precioestfecha_1
begin
--   Manifest
--     DATA PROFILE: PrecioEstFecha_1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(20818281852455013)
,p_name=>'PrecioEstFecha_1'
,p_format=>'JSON'
,p_has_header_row=>false
,p_row_selector=>'.'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(20820263992455015)
,p_data_profile_id=>wwv_flow_imp.id(20818281852455013)
,p_name=>'FECHA'
,p_sequence=>5
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>true
,p_selector=>'Fecha'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(20819687881455015)
,p_data_profile_id=>wwv_flow_imp.id(20818281852455013)
,p_name=>'DATA_LIST'
,p_sequence=>10
,p_column_type=>'DATA'
,p_data_type=>'DOCUMENT_FRAGMENT'
,p_has_time_zone=>false
,p_selector=>'ListaEESSPrecio'
);
wwv_flow_imp.component_end;
end;
/
