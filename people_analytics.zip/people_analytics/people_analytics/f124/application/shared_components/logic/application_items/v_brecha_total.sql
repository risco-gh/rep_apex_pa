prompt --application/shared_components/logic/application_items/v_brecha_total
begin
--   Manifest
--     APPLICATION ITEM: V_BRECHA_TOTAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(16564891816023869)
,p_name=>'V_BRECHA_TOTAL'
,p_protection_level=>'I'
,p_version_scn=>41241727503221
);
wwv_flow_imp.component_end;
end;
/
