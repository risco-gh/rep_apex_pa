prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>13438269157088331
,p_default_application_id=>124
,p_default_id_offset=>0
,p_default_owner=>'PEOPLE_ANALYTICS'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'WS Mapa Gasolineras old'
,p_alias=>'WS-MAPA-GASOLINERAS-OLD'
,p_step_title=>'WS Mapa Gasolineras'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(13465178960287177)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'PEOPLE_ANALYTICS_WS'
,p_last_upd_yyyymmddhh24miss=>'20240507110829'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18731710018408048)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19007139200188103)
,p_plug_name=>unistr('Gasolinera m\00E1s barata por municipio')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(19007699348188108)
,p_region_id=>wwv_flow_imp.id(19007139200188103)
,p_height=>250
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
,p_copyright_notice=>' '
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(19010640169188138)
,p_map_region_id=>wwv_flow_imp.id(19007699348188108)
,p_name=>unistr('M\00E1s barata P')
,p_layer_type=>'HEATMAP'
,p_display_sequence=>10
,p_visible_min_zoom_level=>3
,p_visible_max_zoom_level=>5
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cge.idprovincia, cge.latitud latitud, cge.longitud_wgs84 longitud, VALOR',
'from (',
'select ideess,',
'case',
' when :P9_NEW = ''PR1'' then PRECIO_GASOLEO_A',
' when :P9_NEW = ''PR2'' then PRECIO_GASOLEO_B',
' when :P9_NEW = ''PR3'' then PRECIO_GASOLEO_PREMIUM',
' when :P9_NEW = ''PR4'' then PRECIO_GASOLINA_95_E5',
' when :P9_NEW = ''PR5'' then PRECIO_GASOLINA_98_E5',
' when :P9_NEW = ''PR6'' then PRECIO_GASOLINA_95_E10',
' when :P9_NEW = ''PR7'' then PRECIO_GASOLINA_98_E10',
' when :P9_NEW = ''PR8'' then PRECIO_GASOLINA_95_E5_PREMIUM',
' end VALOR',
'from ws_precios_carburantes) prc',
' join ws_precios_carburantes cge on (cge.ideess = prc.ideess)',
' where VALOR is not null',
''))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_fill_color_spectr_name=>'TealGrn'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(19007746649188109)
,p_map_region_id=>wwv_flow_imp.id(19007699348188108)
,p_name=>unistr('M\00E1s barata M')
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_visible_min_zoom_level=>6
,p_visible_max_zoom_level=>18
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select tb1.ideess ideess, tb2.municipio municipio, tb2."R\00D3TULO" nombre_es, tb2.latitud latitud, tb2.longitud_wgs84 longitud, valor from ( '),
'select ideess, idmunicipio, valor, rank() over (partition by idmunicipio order by valor asc) n_ord',
'from (',
'select ideess, idmunicipio,',
'case',
' when :P9_NEW = ''PR1'' then PRECIO_GASOLEO_A',
' when :P9_NEW = ''PR2'' then PRECIO_GASOLEO_B',
' when :P9_NEW = ''PR3'' then PRECIO_GASOLEO_PREMIUM',
' when :P9_NEW = ''PR4'' then PRECIO_GASOLINA_95_E5',
' when :P9_NEW = ''PR5'' then PRECIO_GASOLINA_98_E5',
' when :P9_NEW = ''PR6'' then PRECIO_GASOLINA_95_E10',
' when :P9_NEW = ''PR7'' then PRECIO_GASOLINA_98_E10',
' when :P9_NEW = ''PR8'' then PRECIO_GASOLINA_95_E5_PREMIUM',
' end VALOR',
'from ws_precios_carburantes) where valor is not null) tb1',
'join ws_precios_carburantes tb2 on (tb2.ideess = tb1.ideess)',
'where n_ord = 1'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_fill_color=>'#16b501'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Triangle'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&MUNICIPIO.<br>E.S. &NOMBRE_ES.<br>PRECIO: &VALOR.</b>'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19008847097188120)
,p_plug_name=>unistr('Gasolinera m\00E1s cara por municipio')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(19009374628188125)
,p_region_id=>wwv_flow_imp.id(19008847097188120)
,p_height=>250
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
,p_copyright_notice=>' '
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(19010749306188139)
,p_map_region_id=>wwv_flow_imp.id(19009374628188125)
,p_name=>unistr('M\00E1s cara P')
,p_layer_type=>'HEATMAP'
,p_display_sequence=>10
,p_visible_min_zoom_level=>3
,p_visible_max_zoom_level=>5
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cge.idprovincia, cge.latitud latitud, cge.longitud_wgs84 longitud, VALOR',
'from (',
'select ideess,',
'case',
' when :P9_NEW = ''PR1'' then PRECIO_GASOLEO_A',
' when :P9_NEW = ''PR2'' then PRECIO_GASOLEO_B',
' when :P9_NEW = ''PR3'' then PRECIO_GASOLEO_PREMIUM',
' when :P9_NEW = ''PR4'' then PRECIO_GASOLINA_95_E5',
' when :P9_NEW = ''PR5'' then PRECIO_GASOLINA_98_E5',
' when :P9_NEW = ''PR6'' then PRECIO_GASOLINA_95_E10',
' when :P9_NEW = ''PR7'' then PRECIO_GASOLINA_98_E10',
' when :P9_NEW = ''PR8'' then PRECIO_GASOLINA_95_E5_PREMIUM',
' end VALOR',
'from ws_precios_carburantes) prc',
' join ws_precios_carburantes cge on (cge.ideess = prc.ideess)',
' where VALOR is not null',
'',
''))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_fill_color_spectr_name=>'Burg'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(19009473724188126)
,p_map_region_id=>wwv_flow_imp.id(19009374628188125)
,p_name=>unistr('M\00E1s cara M')
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_visible_min_zoom_level=>6
,p_visible_max_zoom_level=>18
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select tb1.ideess ideess, tb2.municipio municipio, tb2."R\00D3TULO" nombre_es, tb2.latitud latitud, tb2.longitud_wgs84 longitud, valor from ( '),
'select ideess, idmunicipio, valor, rank() over (partition by idmunicipio order by valor desc) n_ord',
'from (',
'select ideess, idmunicipio,',
'case',
' when :P9_NEW = ''PR1'' then PRECIO_GASOLEO_A',
' when :P9_NEW = ''PR2'' then PRECIO_GASOLEO_B',
' when :P9_NEW = ''PR3'' then PRECIO_GASOLEO_PREMIUM',
' when :P9_NEW = ''PR4'' then PRECIO_GASOLINA_95_E5',
' when :P9_NEW = ''PR5'' then PRECIO_GASOLINA_98_E5',
' when :P9_NEW = ''PR6'' then PRECIO_GASOLINA_95_E10',
' when :P9_NEW = ''PR7'' then PRECIO_GASOLINA_98_E10',
' when :P9_NEW = ''PR8'' then PRECIO_GASOLINA_95_E5_PREMIUM',
' end VALOR',
'from ws_precios_carburantes) where valor is not null) tb1',
'join ws_precios_carburantes tb2 on (tb2.ideess = tb1.ideess)',
'where n_ord = 1'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_fill_color=>'#fa3636'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Triangle'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&MUNICIPIO.<br>E.S. &NOMBRE_ES.<br>PRECIO: &VALOR.</b>'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49474896963455428)
,p_plug_name=>'Precio medio por provincia'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13556604986287250)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(18975860541025210)
,p_region_id=>wwv_flow_imp.id(49474896963455428)
,p_height=>250
,p_navigation_bar_type=>'NONE'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-3'
,p_init_position_lat_static=>'40'
,p_init_zoomlevel_static=>'4'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM'
,p_copyright_notice=>' '
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(18976306067025211)
,p_map_region_id=>wwv_flow_imp.id(18975860541025210)
,p_name=>'Precio por provincia'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cge.provincia, latitud, longitud, VALOR, decode (nvl(VALOR, 0), 0, ''#a69a9a'', ''#fc6914'') B_COLOR',
'from (',
'select idprovincia,',
'case',
' when :P9_NEW = ''PR1'' then round(avg(PRECIO_GASOLEO_A), 4)',
' when :P9_NEW = ''PR2'' then round(avg(PRECIO_GASOLEO_B), 4)',
' when :P9_NEW = ''PR3'' then round(avg(PRECIO_GASOLEO_PREMIUM), 4)',
' when :P9_NEW = ''PR4'' then round(avg(PRECIO_GASOLINA_95_E5), 4)',
' when :P9_NEW = ''PR5'' then round(avg(PRECIO_GASOLINA_98_E5), 4)',
' when :P9_NEW = ''PR6'' then round(avg(PRECIO_GASOLINA_95_E10), 4)',
' when :P9_NEW = ''PR7'' then round(avg(PRECIO_GASOLINA_98_E10), 4)',
' when :P9_NEW = ''PR8'' then round(avg(PRECIO_GASOLINA_95_E5_PREMIUM), 4)',
' end VALOR',
'from ws_precios_carburantes',
' group by idprovincia) prc',
' join centros_geo cge on (cge.id = prc.idprovincia);'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUD'
,p_latitude_column=>'LATITUD'
,p_fill_color=>'&B_COLOR.'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Pin Square'
,p_point_svg_shape_scale=>'&VALOR.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<b>&PROVINCIA.: &VALOR.<b/>'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19007095390188102)
,p_name=>'P9_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18731710018408048)
,p_prompt=>'<b>Producto</b>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:GASOLEO A;PR1,GASOLEO B;PR2,GASOLEO PREMIUM;PR3,GASOLINA 95 E5;PR4,GASOLINA 98 E5;PR5,GASOLINA 95 E10;PR6,GASOLINA 98 E10;PR7,GASOLINA 95 E5 PREMIUM;PR8'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(13635444852287323)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
